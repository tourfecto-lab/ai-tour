ربط خريطة المقالات — استضافة tourfecto.com فقط
ارفع robots.txt إلى جذر موقع العميل ليظهر على https://tourfecto.com/robots.txt.
الملف يحافظ على القواعد العامة التي قرأناها من الموقع، ويضيف فقط:
Sitemap: https://tourfecto.com/?tf_guides_sitemap=1
لو عدلت robots.txt بعد الفحص، أضف السطر للنسخة الأحدث بدل استبدال قواعدك الجديدة.
لا ترفع هذا الملف على tourfecto.pro. لا يضمن الإعلان عن الخريطة فهرسة Google.
