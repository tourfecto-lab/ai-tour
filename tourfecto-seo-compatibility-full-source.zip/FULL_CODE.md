# Full code for every changed or added file

## app/Controllers/AiVisibilityController.php

````php
<?php
final class AiVisibilityController extends Controller
{
    public function data(array $params=[]): array
    {
        if(!$this->isAuthenticated())return $this->error('Unauthorized',401);
        if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'&&($err=$this->verifyCsrf()))return $err;
        try{$uid=(int)$this->user['id'];$wid=(int)$this->get('website_id');$svc=new AiVisibilityService($this->db);$action=$params['action']??'overview';
            if(method_exists($svc,'save')&&method_exists($svc,'entities'))return $this->success($this->currentContract($svc,$action,$uid,$wid,(int)$this->get('market_id')));
            $result=match($action){
                'generate'=>$svc->generate($uid,$wid,(int)$this->get('market_id')),
                'question'=>$svc->saveQuestion($uid,$wid,(int)$this->get('id'),trim((string)$this->get('question')),$this->get('approved')===true),
                'identity'=>$svc->identity($uid,$wid,(array)$this->get('aliases',[]),(array)$this->get('profile_urls',[])),
                default=>$svc->overview($uid,$wid)
            };return $this->success(AiVisibilityPresentation::customer($result));
        }catch(InvalidArgumentException $e){return $this->error($e->getMessage(),422);}
        catch(Throwable $e){
            Logger::error('AI Visibility operation unavailable',[
                'action'=>$params['action']??'overview','website_id'=>(int)$this->get('website_id'),
                'user_id'=>(int)$this->user['id'],'exception'=>get_class($e),
                'error'=>$e->getMessage(),'file'=>$e->getFile(),'line'=>$e->getLine()
            ]);
            return $this->error('تعذر تحميل النتائج دلوقتي. جرّب مرة تانية أو تواصل مع الدعم.',503);
        }
    }
    /** Current package uses versioned, whole-list approval; do not emulate per-question consent. */
    private function currentContract(object $service,string $action,int $uid,int $wid,int $mid): array
    {
        if($action==='generate'){
            $draft=$service->generate($uid,$wid,$mid);
            $resolved=(int)$draft['market']['id'];
            $set=$service->set($uid,$wid,$resolved);
            return ['question_mode'=>'set','draft_questions'=>$draft['questions'],'set_version'=>(int)($set['version']??0),'market_id'=>$resolved];
        }
        if($action==='question'){
            $questions=$this->get('questions');if(is_string($questions))$questions=array_values(array_filter(array_map('trim',explode("\n",$questions)),static fn($q)=>$q!==''));$version=filter_var($this->get('version'),FILTER_VALIDATE_INT);
            if(!is_array($questions)||$version===false||$version<0)throw new InvalidArgumentException('Review and save the complete question list with its current version. / راجع واحفظ قائمة الأسئلة كاملة بإصدارها الحالي.');
            $service->save($uid,$wid,$mid,$questions,$version,$this->get('approved')===true);
            return ['saved'=>true];
        }
        if($action==='identity'){
            $version=filter_var($this->get('version'),FILTER_VALIDATE_INT);
            if($version===false||$version<0||$this->get('confirmed')!==true)throw new InvalidArgumentException('Confirm the current company identity before saving. / أكد بيانات الشركة الحالية قبل الحفظ.');
            $lines=static fn($value)=>is_string($value)?array_values(array_filter(array_map('trim',explode("\n",$value)),static fn($line)=>$line!=='')):(array)$value;
            $service->entities($uid,$wid,$lines($this->get('aliases',[])),$lines($this->get('profile_urls',$this->get('profiles',[]))),(string)$this->get('address',''),$version,true);
            return ['saved'=>true];
        }
        $result=$service->overview($uid,$wid,$mid);
        $markets=new SeoMarketService($this->db);
        $result['markets']=$markets->markets($wid,$uid);
        return AiVisibilityPresentation::customer($result);
    }
    public function save(array $params=[]): array {return $this->data(['action'=>'question']);}
    public function entities(array $params=[]): array {return $this->data(['action'=>'identity']);}
    public function generate(array $params=[]): array {return $this->data(['action'=>'generate']);}
    public function question(array $params=[]): array {return $this->data(['action'=>'question']);}
    public function identity(array $params=[]): array {return $this->data(['action'=>'identity']);}
    public function llms(array $params=[]): array
    {
        if(!$this->isAuthenticated())return $this->error('Unauthorized',401);
        try{$service=new AiVisibilityService($this->db);if(method_exists($service,'llmsDraft'))return $this->success($service->llmsDraft((int)$this->user['id'],(int)$this->get('website_id')));$site=(new SeoMarketService($this->db))->owned((int)$this->get('website_id'),(int)$this->user['id']);$ctx=(new SeoExpertPageContext())->fresh($site['main_url']);if(empty($ctx['ok']))throw new RuntimeException('page_unavailable');return $this->success(['draft'=>(new LlmsSiteSummary())->fromContext($ctx),'status'=>'draft_requires_review','note'=>'راجع البيانات؛ النشر من خلال دورة الموصل الحالية مع موافقة وتحقق وإمكانية رجوع. مفيش ضمان ترتيب.']);}catch(Throwable $e){return $this->error('تعذر قراءة الصفحات العامة',422);}
    }
    /** Compatibility with deployed web routes that still dispatch to index. */
    public function index(array $params=[]): array {return $this->page($params);}
    public function page(array $params=[]): array {if(!$this->isAuthenticated())return $this->error('Unauthorized',401);ob_start();require dirname(__DIR__).'/Views/AiVisibility/index.php';$body=ob_get_clean();
        $english=function_exists('current_lang')&&current_lang()!=='ar';
        echo $this->renderPanelPage('ai_analyze',$english?'Your AI visibility':'ظهورك في الذكاء الصناعي',$english?'Measured questions and sources':'قياسات فعلية للأسئلة والمصادر، بدون تقديرات',$body);return [];}
}

````

## app/Lang/ai_visibility_ar.php

````php
<?php
/** AI visibility customer messages; language selected by current_lang(). */
return [
    'هل بيظهر اسم شركتك في إجابات الذكاء الاصطناعي؟' => 'هل بيظهر اسم شركتك في إجابات الذكاء الاصطناعي؟',
    'راجع أسئلة عملائك، وافق على قياسها، وتابع النتائج ومصادرها.' => 'راجع أسئلة عملائك، وافق على قياسها، وتابع النتائج ومصادرها.',
    'تحديث النتائج' => 'تحديث النتائج',
    '١. اختار موقعك' => '١. اختار موقعك',
    'جارٍ تحميل المواقع…' => 'جارٍ تحميل المواقع…',
    '٢. اختار البلد واللغة' => '٢. اختار البلد واللغة',
    'اختار الموقع الأول' => 'اختار الموقع الأول',
    'جارٍ تجهيز حسابك' => 'جارٍ تجهيز حسابك',
    'بنحمّل المواقع والأسواق المتاحة…' => 'بنحمّل المواقع والأسواق المتاحة…',
    'النتائج' => 'النتائج',
    'الأسئلة' => 'الأسئلة',
    'بيانات الشركة' => 'بيانات الشركة',
    'أحدث قياسات ظهور شركتك' => 'أحدث قياسات ظهور شركتك',
    'الإجابات والمصادر' => 'الإجابات والمصادر',
    'راجع مقتطف الإجابة وروابط المصادر للتأكد من النتيجة.' => 'راجع مقتطف الإجابة وروابط المصادر للتأكد من النتيجة.',
    'تطور النتائج خلال آخر ٨ أسابيع' => 'تطور النتائج خلال آخر ٨ أسابيع',
    'اقتراحات تحسين مبنية على النتائج' => 'اقتراحات تحسين مبنية على النتائج',
    'القياس عينة من إجابات البحث في وقت محدد، مش ضمان ظهور في تطبيقات الشات. ترتيب الاسم محسوب وسط الشركات المتابَعة فقط.' => 'القياس عينة من إجابات البحث في وقت محدد، مش ضمان ظهور في تطبيقات الشات. ترتيب الاسم محسوب وسط الشركات المتابَعة فقط.',
    '٣. راجع الأسئلة ووافق على اللي يناسبك' => '٣. راجع الأسئلة ووافق على اللي يناسبك',
    'الأسئلة بتتجهّز من كلمات البحث الحقيقية. كل سؤال لازم تحفظ موافقتك عليه عشان يدخل القياس الأسبوعي.' => 'الأسئلة بتتجهّز من كلمات البحث الحقيقية. كل سؤال لازم تحفظ موافقتك عليه عشان يدخل القياس الأسبوعي.',
    'تجهيز أسئلة مقترحة' => 'تجهيز أسئلة مقترحة',
    'إدارة الأسواق وكلمات البحث' => 'إدارة الأسواق وكلمات البحث',
    'أكد هوية شركتك' => 'أكد هوية شركتك',
    'ابدأ بتأكيد الاسم والخدمات من بيانات الشركة. الأسماء البديلة والروابط هنا بتساعدنا نميّز شركتك عن الشركات المشابهة.' => 'ابدأ بتأكيد الاسم والخدمات من بيانات الشركة. الأسماء البديلة والروابط هنا بتساعدنا نميّز شركتك عن الشركات المشابهة.',
    'مراجعة بيانات الشركة' => 'مراجعة بيانات الشركة',
    'أسماء بديلة لشركتك بالعربي أو الإنجليزي' => 'أسماء بديلة لشركتك بالعربي أو الإنجليزي',
    'روابط صفحات شركتك الرسمية' => 'روابط صفحات شركتك الرسمية',
    'تغيير الهوية يحتاج مراجعة الأسئلة والموافقة عليها من جديد.' => 'تغيير الهوية يحتاج مراجعة الأسئلة والموافقة عليها من جديد.',
    'حفظ الأسماء والروابط' => 'حفظ الأسماء والروابط',
    'اختياري: مسودة تعريف الموقع لمحركات الذكاء الاصطناعي' => 'اختياري: مسودة تعريف الموقع لمحركات الذكاء الاصطناعي',
    'جهّز مسودة llms.txt من صفحات موقعك العامة. راجعها قبل النشر؛ الزر ده مش بينشرها على موقعك.' => 'جهّز مسودة llms.txt من صفحات موقعك العامة. راجعها قبل النشر؛ الزر ده مش بينشرها على موقعك.',
    'تجهيز المسودة' => 'تجهيز المسودة',
    'جارٍ التحميل…' => 'جارٍ التحميل…',
    'تعذر إتمام الطلب. حاول تاني.' => 'تعذر إتمام الطلب. حاول تاني.',
    'تعذر تحميل البيانات' => 'تعذر تحميل البيانات',
    'اختيار موقعك محفوظ. اضغط تحديث النتائج لإعادة المحاولة.' => 'اختيار موقعك محفوظ. اضغط تحديث النتائج لإعادة المحاولة.',
    'إعادة المحاولة' => 'إعادة المحاولة',
    'غير متاح' => 'غير متاح',
    'غير مقاس' => 'غير مقاس',
    'مفيش مصدر متاح' => 'مفيش مصدر متاح',
    'أكد بيانات الشركة الأول' => 'أكد بيانات الشركة الأول',
    'راجع اسم الشركة وخدماتها وروابطها الحالية، واحفظ تأكيدك قبل تجهيز الأسئلة.' => 'راجع اسم الشركة وخدماتها وروابطها الحالية، واحفظ تأكيدك قبل تجهيز الأسئلة.',
    'اختار سوق لموقعك' => 'اختار سوق لموقعك',
    'حدد البلد واللغة من إدارة الأسواق، وبعدها حدّث النتائج.' => 'حدد البلد واللغة من إدارة الأسواق، وبعدها حدّث النتائج.',
    'الخطوة التالية: جهّز أسئلة عملائك' => 'الخطوة التالية: جهّز أسئلة عملائك',
    'أكد بيانات الشركة وكلمات البحث الحقيقية، وبعدها جهّز الأسئلة وراجعها.' => 'أكد بيانات الشركة وكلمات البحث الحقيقية، وبعدها جهّز الأسئلة وراجعها.',
    'تجهيز الأسئلة' => 'تجهيز الأسئلة',
    'الخطوة التالية: راجع الأسئلة واحفظ موافقتك' => 'الخطوة التالية: راجع الأسئلة واحفظ موافقتك',
    'الأسئلة غير المعتمدة مش بتدخل القياس. اختار الأسئلة المناسبة واحفظ كل سؤال.' => 'الأسئلة غير المعتمدة مش بتدخل القياس. اختار الأسئلة المناسبة واحفظ كل سؤال.',
    'مراجعة الأسئلة' => 'مراجعة الأسئلة',
    'أسئلتك المعتمدة جاهزة للقياس الأسبوعي' => 'أسئلتك المعتمدة جاهزة للقياس الأسبوعي',
    ' سؤال معتمد في السوق ده. النتائج هتظهر بعد تشغيل القياس المجدول؛ تحديث النتائج مش بيبدأ قياس جديد.' => ' سؤال معتمد في السوق ده. النتائج هتظهر بعد تشغيل القياس المجدول؛ تحديث النتائج مش بيبدأ قياس جديد.',
    'نتائج السوق متاحة للمراجعة' => 'نتائج السوق متاحة للمراجعة',
    'راجع الإجابات ومصادرها. تحديث النتائج بيعرض أحدث قياسات محفوظة، ومش بيبدأ قياس جديد.' => 'راجع الإجابات ومصادرها. تحديث النتائج بيعرض أحدث قياسات محفوظة، ومش بيبدأ قياس جديد.',
    'عرض الإجابات والمصادر' => 'عرض الإجابات والمصادر',
    'خدمة بحث' => 'خدمة بحث',
    'نسبة الإجابات اللي ذكرت شركتك' => 'نسبة الإجابات اللي ذكرت شركتك',
    'اقتباس موقعك: ' => 'اقتباس موقعك: ',
    ' إجابة مقاسة' => ' إجابة مقاسة',
    ' — قياس قديم' => ' — قياس قديم',
    ' — عينة جزئية' => ' — عينة جزئية',
    'لسه مفيش قياسات محفوظة للسوق ده.' => 'لسه مفيش قياسات محفوظة للسوق ده.',
    'لسه مفيش نتائج لعرضها.' => 'لسه مفيش نتائج لعرضها.',
    'النسب من العينة المقاسة بتاريخها، مش من كل إجابات الخدمة.' => 'النسب من العينة المقاسة بتاريخها، مش من كل إجابات الخدمة.',
    'عدم وجود قياس مش معناه إن نسبة ظهورك صفر.' => 'عدم وجود قياس مش معناه إن نسبة ظهورك صفر.',
    ' سؤال معتمد من ' => ' سؤال معتمد من ',
    ' في السوق المختار.' => ' في السوق المختار.',
    'لسه مفيش أسئلة للسوق ده. جهّز كلمات البحث الحقيقية الأول، وبعدها اضغط تجهيز أسئلة مقترحة.' => 'لسه مفيش أسئلة للسوق ده. جهّز كلمات البحث الحقيقية الأول، وبعدها اضغط تجهيز أسئلة مقترحة.',
    'السؤال ' => 'السؤال ',
    'حفظ السؤال' => 'حفظ السؤال',
    'موافق على قياس السؤال أسبوعيًا' => 'موافق على قياس السؤال أسبوعيًا',
    'حفظ التغييرات' => 'حفظ التغييرات',
    'اكتب السؤال قبل الحفظ.' => 'اكتب السؤال قبل الحفظ.',
    'تم حفظ السؤال وموقف الموافقة.' => 'تم حفظ السؤال وموقف الموافقة.',
    'ابدأ بتجهيز الأسئلة من كلمات البحث، وبعدها هتظهر هنا للمراجعة.' => 'ابدأ بتجهيز الأسئلة من كلمات البحث، وبعدها هتظهر هنا للمراجعة.',
    'الخدمة' => 'الخدمة',
    'السؤال' => 'السؤال',
    'تم ذكر الشركة' => 'تم ذكر الشركة',
    'لم تُذكر الشركة' => 'لم تُذكر الشركة',
    'ذكر شركتك' => 'ذكر شركتك',
    'تم الاقتباس' => 'تم الاقتباس',
    'لم يتم الاقتباس' => 'لم يتم الاقتباس',
    'اقتباس موقعك' => 'اقتباس موقعك',
    'المصادر' => 'المصادر',
    'مقتطف الإجابة' => 'مقتطف الإجابة',
    'تاريخ القياس' => 'تاريخ القياس',
    'بعد أول قياس، الإجابات ومصادرها هتظهر هنا.' => 'بعد أول قياس، الإجابات ومصادرها هتظهر هنا.',
    'الأسبوع' => 'الأسبوع',
    'نسبة الذكر' => 'نسبة الذكر',
    'الاقتباس' => 'الاقتباس',
    'اتجاه النتائج بيتكوّن مع تراكم القياسات الأسبوعية.' => 'اتجاه النتائج بيتكوّن مع تراكم القياسات الأسبوعية.',
    'المهمة' => 'المهمة',
    'خطوات المراجعة' => 'خطوات المراجعة',
    'المصدر' => 'المصدر',
    'للمراجعة' => 'للمراجعة',
    'تم التحقق' => 'تم التحقق',
    'مكتملة' => 'مكتملة',
    'تم استبعادها' => 'تم استبعادها',
    'تم التطبيق' => 'تم التطبيق',
    'الحالة' => 'الحالة',
    'مفيش اقتراحات تحسين متاحة حاليًا.' => 'مفيش اقتراحات تحسين متاحة حاليًا.',
    'جارٍ تحميل حالة الموقع' => 'جارٍ تحميل حالة الموقع',
    'بنحمّل الأسواق والأسئلة والقياسات المحفوظة…' => 'بنحمّل الأسواق والأسئلة والقياسات المحفوظة…',
    'تعذر تحميل المواقع.' => 'تعذر تحميل المواقع.',
    'موقعي' => 'موقعي',
    'أضف موقعك عشان تبدأ' => 'أضف موقعك عشان تبدأ',
    'اربط موقعك بحسابك، وبعدها ارجع هنا لاختيار السوق وتجهيز الأسئلة.' => 'اربط موقعك بحسابك، وبعدها ارجع هنا لاختيار السوق وتجهيز الأسئلة.',
    'إدارة المواقع' => 'إدارة المواقع',
    'جارٍ تحميل الأسواق…' => 'جارٍ تحميل الأسواق…',
    'تعذر تحميل الأسواق' => 'تعذر تحميل الأسواق',
    'مفيش سوق مضاف' => 'مفيش سوق مضاف',
    'قائمة الأسئلة — سؤال واحد في كل سطر' => 'قائمة الأسئلة — سؤال واحد في كل سطر',
    'حفظ القائمة' => 'حفظ القائمة',
    'راجعت القائمة كاملة وأوافق على قياسها أسبوعيًا' => 'راجعت القائمة كاملة وأوافق على قياسها أسبوعيًا',
    'راجع من 10 إلى 30 سؤالًا بدون اسم شركتك. الموافقة بتخص القائمة كاملة، وأي تعديل يحتاج مراجعتها.' => 'راجع من 10 إلى 30 سؤالًا بدون اسم شركتك. الموافقة بتخص القائمة كاملة، وأي تعديل يحتاج مراجعتها.',
    'احفظ من 10 إلى 30 سؤالًا في القائمة.' => 'احفظ من 10 إلى 30 سؤالًا في القائمة.',
    'تم حفظ القائمة وموقف الموافقة.' => 'تم حفظ القائمة وموقف الموافقة.',
    'اتجهزت مسودة الأسئلة. راجع كل سؤال واحفظ موافقتك.' => 'اتجهزت مسودة الأسئلة. راجع كل سؤال واحفظ موافقتك.',
    'تم حفظ هوية الشركة. راجع الأسئلة واحفظ موافقتك عليها من جديد.' => 'تم حفظ هوية الشركة. راجع الأسئلة واحفظ موافقتك عليها من جديد.',
    'راجع المسودة قبل النشر.' => 'راجع المسودة قبل النشر.',
    'المسودة جاهزة للمراجعة، ولم يتم نشرها.' => 'المسودة جاهزة للمراجعة، ولم يتم نشرها.',
    'متابعة ظهور الشركة' => 'متابعة ظهور الشركة',
    'اسم واحد في كل سطر' => 'اسم واحد في كل سطر',
    'رابط كامل في كل سطر' => 'رابط كامل في كل سطر',
    'الموافقة بتخص قائمة الأسئلة كاملة. راجع النصوص واحفظ القائمة بعد أي تعديل.' => 'الموافقة بتخص قائمة الأسئلة كاملة. راجع النصوص واحفظ القائمة بعد أي تعديل.',
    'أؤكد أن أسماء الشركة وروابطها صحيحة.' => 'أؤكد أن أسماء الشركة وروابطها صحيحة.',
    'أكد صحة أسماء الشركة وروابطها قبل الحفظ.' => 'أكد صحة أسماء الشركة وروابطها قبل الحفظ.',
];

````

## app/Lang/ai_visibility_en.php

````php
<?php
/** AI visibility customer messages; language selected by current_lang(). */
return [
    'هل بيظهر اسم شركتك في إجابات الذكاء الاصطناعي؟' => 'Does your company appear in AI answers?',
    'راجع أسئلة عملائك، وافق على قياسها، وتابع النتائج ومصادرها.' => 'Review traveler questions, approve measurement, and track results with sources.',
    'تحديث النتائج' => 'Refresh results',
    '١. اختار موقعك' => '1. Choose your website',
    'جارٍ تحميل المواقع…' => 'Loading websites…',
    '٢. اختار البلد واللغة' => '2. Choose country and language',
    'اختار الموقع الأول' => 'Choose a website first',
    'جارٍ تجهيز حسابك' => 'Preparing your account',
    'بنحمّل المواقع والأسواق المتاحة…' => 'Loading available websites and markets…',
    'النتائج' => 'Results',
    'الأسئلة' => 'Questions',
    'بيانات الشركة' => 'Company details',
    'أحدث قياسات ظهور شركتك' => 'Latest AI visibility measurements',
    'الإجابات والمصادر' => 'Answers and sources',
    'راجع مقتطف الإجابة وروابط المصادر للتأكد من النتيجة.' => 'Check the answer excerpt and source links to verify the result.',
    'تطور النتائج خلال آخر ٨ أسابيع' => 'Results over the last 8 weeks',
    'اقتراحات تحسين مبنية على النتائج' => 'Suggestions based on measured results',
    'القياس عينة من إجابات البحث في وقت محدد، مش ضمان ظهور في تطبيقات الشات. ترتيب الاسم محسوب وسط الشركات المتابَعة فقط.' => 'These are search answer samples taken at a specific time, not guaranteed visibility in chat apps. Mention order only compares tracked companies.',
    '٣. راجع الأسئلة ووافق على اللي يناسبك' => '3. Review and approve suitable questions',
    'الأسئلة بتتجهّز من كلمات البحث الحقيقية. كل سؤال لازم تحفظ موافقتك عليه عشان يدخل القياس الأسبوعي.' => 'Questions use real keyword data. Save your approval before questions can enter weekly measurement.',
    'تجهيز أسئلة مقترحة' => 'Generate suggested questions',
    'إدارة الأسواق وكلمات البحث' => 'Manage markets and keywords',
    'أكد هوية شركتك' => 'Confirm your company identity',
    'ابدأ بتأكيد الاسم والخدمات من بيانات الشركة. الأسماء البديلة والروابط هنا بتساعدنا نميّز شركتك عن الشركات المشابهة.' => 'First confirm your company name and services. Alternative names and links help distinguish your company from others.',
    'مراجعة بيانات الشركة' => 'Review company details',
    'أسماء بديلة لشركتك بالعربي أو الإنجليزي' => 'Alternative company names in Arabic or English',
    'روابط صفحات شركتك الرسمية' => 'Official company profile links',
    'تغيير الهوية يحتاج مراجعة الأسئلة والموافقة عليها من جديد.' => 'Changing the identity requires reviewing and approving questions again.',
    'حفظ الأسماء والروابط' => 'Save names and links',
    'اختياري: مسودة تعريف الموقع لمحركات الذكاء الاصطناعي' => 'Optional: draft a site summary for AI tools',
    'جهّز مسودة llms.txt من صفحات موقعك العامة. راجعها قبل النشر؛ الزر ده مش بينشرها على موقعك.' => 'Draft llms.txt from your public pages. Review it before publishing; this button does not publish to your website.',
    'تجهيز المسودة' => 'Prepare draft',
    'جارٍ التحميل…' => 'Loading…',
    'تعذر إتمام الطلب. حاول تاني.' => 'Could not complete the request. Please try again.',
    'تعذر تحميل البيانات' => 'Could not load data',
    'اختيار موقعك محفوظ. اضغط تحديث النتائج لإعادة المحاولة.' => 'Your website selection is saved. Refresh results to retry.',
    'إعادة المحاولة' => 'Retry',
    'غير متاح' => 'Unavailable',
    'غير مقاس' => 'Not measured',
    'مفيش مصدر متاح' => 'No source available',
    'أكد بيانات الشركة الأول' => 'Confirm company details first',
    'راجع اسم الشركة وخدماتها وروابطها الحالية، واحفظ تأكيدك قبل تجهيز الأسئلة.' => 'Review your current company name, services and links, then confirm them before generating questions.',
    'اختار سوق لموقعك' => 'Choose a market for your website',
    'حدد البلد واللغة من إدارة الأسواق، وبعدها حدّث النتائج.' => 'Set the country and language in market settings, then refresh results.',
    'الخطوة التالية: جهّز أسئلة عملائك' => 'Next: prepare traveler questions',
    'أكد بيانات الشركة وكلمات البحث الحقيقية، وبعدها جهّز الأسئلة وراجعها.' => 'Confirm company details and real keywords, then generate and review questions.',
    'تجهيز الأسئلة' => 'Prepare questions',
    'الخطوة التالية: راجع الأسئلة واحفظ موافقتك' => 'Next: review questions and save approval',
    'الأسئلة غير المعتمدة مش بتدخل القياس. اختار الأسئلة المناسبة واحفظ كل سؤال.' => 'Unapproved questions are not measured. Select suitable questions and save your review.',
    'مراجعة الأسئلة' => 'Review questions',
    'أسئلتك المعتمدة جاهزة للقياس الأسبوعي' => 'Your approved questions are ready for weekly measurement',
    ' سؤال معتمد في السوق ده. النتائج هتظهر بعد تشغيل القياس المجدول؛ تحديث النتائج مش بيبدأ قياس جديد.' => ' approved questions in this market. Results appear after scheduled measurement runs; refreshing does not start a new measurement.',
    'نتائج السوق متاحة للمراجعة' => 'Market results are ready for review',
    'راجع الإجابات ومصادرها. تحديث النتائج بيعرض أحدث قياسات محفوظة، ومش بيبدأ قياس جديد.' => 'Review answers and sources. Refreshing shows saved measurements and does not start a new measurement.',
    'عرض الإجابات والمصادر' => 'View answers and sources',
    'خدمة بحث' => 'Search service',
    'نسبة الإجابات اللي ذكرت شركتك' => 'Share of measured answers mentioning your company',
    'اقتباس موقعك: ' => 'Website citation rate: ',
    ' إجابة مقاسة' => ' measured answers',
    ' — قياس قديم' => ' — older measurement',
    ' — عينة جزئية' => ' — partial sample',
    'لسه مفيش قياسات محفوظة للسوق ده.' => 'No saved measurements for this market yet.',
    'لسه مفيش نتائج لعرضها.' => 'No results to display yet.',
    'النسب من العينة المقاسة بتاريخها، مش من كل إجابات الخدمة.' => 'Rates describe the dated sample, not every answer from the service.',
    'عدم وجود قياس مش معناه إن نسبة ظهورك صفر.' => 'No measurement does not mean your visibility rate is zero.',
    ' سؤال معتمد من ' => ' approved questions out of ',
    ' في السوق المختار.' => ' in the selected market.',
    'لسه مفيش أسئلة للسوق ده. جهّز كلمات البحث الحقيقية الأول، وبعدها اضغط تجهيز أسئلة مقترحة.' => 'No questions for this market yet. Prepare real keyword data, then generate suggested questions.',
    'السؤال ' => 'Question ',
    'حفظ السؤال' => 'Save question',
    'موافق على قياس السؤال أسبوعيًا' => 'I approve weekly measurement of this question',
    'حفظ التغييرات' => 'Save changes',
    'اكتب السؤال قبل الحفظ.' => 'Enter a question before saving.',
    'تم حفظ السؤال وموقف الموافقة.' => 'Question and approval saved.',
    'ابدأ بتجهيز الأسئلة من كلمات البحث، وبعدها هتظهر هنا للمراجعة.' => 'Start by generating questions from keywords. They will appear here for review.',
    'الخدمة' => 'Service',
    'السؤال' => 'Question',
    'تم ذكر الشركة' => 'Company mentioned',
    'لم تُذكر الشركة' => 'Company not mentioned',
    'ذكر شركتك' => 'Company mention',
    'تم الاقتباس' => 'Website cited',
    'لم يتم الاقتباس' => 'Website not cited',
    'اقتباس موقعك' => 'Website citation',
    'المصادر' => 'Sources',
    'مقتطف الإجابة' => 'Answer excerpt',
    'تاريخ القياس' => 'Measured at',
    'بعد أول قياس، الإجابات ومصادرها هتظهر هنا.' => 'Answers and sources will appear here after the first measurement.',
    'الأسبوع' => 'Week',
    'نسبة الذكر' => 'Mention rate',
    'الاقتباس' => 'Citation rate',
    'اتجاه النتائج بيتكوّن مع تراكم القياسات الأسبوعية.' => 'The trend builds as weekly measurements accumulate.',
    'المهمة' => 'Task',
    'خطوات المراجعة' => 'Review steps',
    'المصدر' => 'Source',
    'للمراجعة' => 'Needs review',
    'تم التحقق' => 'Verified',
    'مكتملة' => 'Completed',
    'تم استبعادها' => 'Dismissed',
    'تم التطبيق' => 'Applied',
    'الحالة' => 'Status',
    'مفيش اقتراحات تحسين متاحة حاليًا.' => 'No improvement suggestions available yet.',
    'جارٍ تحميل حالة الموقع' => 'Loading website status',
    'بنحمّل الأسواق والأسئلة والقياسات المحفوظة…' => 'Loading markets, questions and saved measurements…',
    'تعذر تحميل المواقع.' => 'Could not load websites.',
    'موقعي' => 'My website',
    'أضف موقعك عشان تبدأ' => 'Add your website to begin',
    'اربط موقعك بحسابك، وبعدها ارجع هنا لاختيار السوق وتجهيز الأسئلة.' => 'Connect a website to your account, then return to choose a market and prepare questions.',
    'إدارة المواقع' => 'Manage websites',
    'جارٍ تحميل الأسواق…' => 'Loading markets…',
    'تعذر تحميل الأسواق' => 'Could not load markets',
    'مفيش سوق مضاف' => 'No market added',
    'قائمة الأسئلة — سؤال واحد في كل سطر' => 'Question list — one question per line',
    'حفظ القائمة' => 'Save list',
    'راجعت القائمة كاملة وأوافق على قياسها أسبوعيًا' => 'I reviewed the complete list and approve weekly measurement',
    'راجع من 10 إلى 30 سؤالًا بدون اسم شركتك. الموافقة بتخص القائمة كاملة، وأي تعديل يحتاج مراجعتها.' => 'Review 10–30 questions without your company name. Approval applies to the whole list; changes require another review.',
    'احفظ من 10 إلى 30 سؤالًا في القائمة.' => 'Save between 10 and 30 questions in the list.',
    'تم حفظ القائمة وموقف الموافقة.' => 'Question list and approval saved.',
    'اتجهزت مسودة الأسئلة. راجع كل سؤال واحفظ موافقتك.' => 'Draft questions are ready. Review them and save your approval.',
    'تم حفظ هوية الشركة. راجع الأسئلة واحفظ موافقتك عليها من جديد.' => 'Company identity saved. Review the questions and save your approval again.',
    'راجع المسودة قبل النشر.' => 'Review the draft before publishing.',
    'المسودة جاهزة للمراجعة، ولم يتم نشرها.' => 'The draft is ready for review and has not been published.',
    'متابعة ظهور الشركة' => 'Company visibility',
    'اسم واحد في كل سطر' => 'One name per line',
    'رابط كامل في كل سطر' => 'One full URL per line',
    'الموافقة بتخص قائمة الأسئلة كاملة. راجع النصوص واحفظ القائمة بعد أي تعديل.' => 'Approval applies to the complete question list. Review the text and save the list after changes.',
    'أؤكد أن أسماء الشركة وروابطها صحيحة.' => 'I confirm that the company names and links are correct.',
    'أكد صحة أسماء الشركة وروابطها قبل الحفظ.' => 'Confirm the company names and links before saving.',
];

````

## app/Services/AiVisibility/AiVisibilityPresentation.php

````php
<?php
/** Customer API projection: internal configuration and provider spending never leave the server. */
final class AiVisibilityPresentation
{
    private const LABELS=['openai'=>'ChatGPT','gemini'=>'Gemini','perplexity'=>'Perplexity'];
    private static function objectArray($value): array
    {
        if(is_string($value))$value=json_decode($value,true);
        return is_array($value)?$value:[];
    }
    private static function rows($value): array
    {
        $rows=[];
        foreach(self::objectArray($value) as $row){
            $row=self::objectArray($row);
            if($row!==[])$rows[]=$row;
        }
        return $rows;
    }
    private static function normalizeCurrent(array $data): array
    {
        if(!isset($data['market'])||!is_array($data['market'])||!array_key_exists('prompt_set',$data))return $data;
        $mid=(int)$data['market']['id'];$metrics=self::objectArray($data['metrics']??[]);$flat=[];$weeks=[];
        foreach(self::objectArray($metrics['providers']??[]) as $provider=>$value){
            if(!isset(self::LABELS[$provider])||!is_array($value))continue;
            if((int)($value['questions']??0)>0)$flat[]=array_intersect_key($value,array_flip(['questions','share_of_voice','citation_rate','citation_questions','week_start','stale','partial']))+['provider'=>$provider,'market_id'=>$mid,'competitors'=>self::objectArray($value['top_competitors']??[])];
            foreach(self::rows($value['trend']??[]) as $point){
                if((int)($point['questions']??0)===0||!isset($point['week']))continue;
                $week=(string)$point['week'];$weeks[$week]['week']=$week;
                $weeks[$week]['providers'][]=array_intersect_key($point,array_flip(['questions','share_of_voice','citation_rate']))+['provider'=>$provider,'market_id'=>$mid];
            }
        }
        ksort($weeks);$data['metrics']=$flat;$data['trend']=array_values($weeks);
        $data['state']=$flat?'measured':'not_measured';
        $set=self::objectArray($data['prompt_set']);
        $data['question_mode']='set';$data['question_set']=['version'=>(int)($set['version']??0),'approved_at'=>$set['approved_at']??null,'questions'=>array_values(array_filter(self::objectArray($set['questions']??[]),'is_string'))];
        $data['questions']=[];foreach($data['question_set']['questions'] as $i=>$question)$data['questions'][]=['id'=>$i,'market_id'=>$mid,'question'=>$question,'approved'=>empty($set['approved_at'])?0:1];
        $entity=self::objectArray($data['entities']??[]);
        $data['identity_aliases']=array_values(array_filter(self::objectArray($entity['aliases']??[]),'is_string'));
        $data['entity_version']=(int)($entity['version']??0);$data['entity_address']=(string)($entity['address']??'');
        $data['aliases']=$data['identity_aliases'];$data['profile_urls']=array_values(array_filter(self::objectArray($entity['profiles']??[]),'is_string'));
        $data['profile_state']=$data['profile_state']??'needs_confirmed_business_profile';
        $data['answers']=array_map(static fn($row)=>$row+['market_id'=>$mid],self::rows($data['answers']??[]));
        return $data;
    }
    public static function customer(array $data): array
    {
        $data=self::normalizeCurrent($data);
        foreach(['metrics','trend','answers','questions','tasks','markets'] as $key)$data[$key]=self::rows($data[$key]??[]);
        $data['providers']=self::objectArray($data['providers']??[]);
        $out=array_intersect_key($data,array_flip(['state','markets','questions','metrics','trend','aliases','profile_urls','position_basis','question_mode','question_set','identity_aliases','entity_version','entity_address','profile_state']));
        $projectMetric=static fn($m)=>array_intersect_key($m,array_flip(['provider','market_id','questions','mentions','citations','citation_questions','share_of_voice','citation_rate','competitors','week_start','stale','partial']));
        $out['metrics']=array_map($projectMetric,$data['metrics']??[]);
        $out['trend']=array_map(static fn($w)=>['week'=>$w['week']??'','providers'=>array_map($projectMetric,self::rows($w['providers']??[]))],$data['trend']??[]);
        $out['setup']='أكد بيانات شركتك، واختار السوق، وبعدها راجع أسئلة عملائك ووافق على الأسئلة اللي تحب تتابع ظهور شركتك فيها. النتائج هتظهر بعد أول قياس.';
        $out['providers']=[];foreach(array_unique(array_merge(array_keys($data['providers']??[]),array_column($data['metrics']??[],'provider'))) as $provider)if(isset(self::LABELS[$provider]))$out['providers'][$provider]=['label'=>self::LABELS[$provider]];
        $out['answers']=array_map(static fn($row)=>array_intersect_key($row,array_flip(['provider','market_id','question','mentioned_brand','cited_domain','brand_position','cited_urls','competitors_mentioned','answer_excerpt','checked_at'])), $data['answers']??[]);
        $out['questions']=array_map(static fn($row)=>array_intersect_key($row,array_flip(['id','market_id','question','approved'])), $data['questions']??[]);
        $out['tasks']=array_map(static function($row){$safe=array_intersect_key($row,array_flip(['title','instructions','status']));$e=self::objectArray($row['evidence_json']??[]);$safe['evidence_json']=json_encode(array_intersect_key($e,array_flip(['url','customer_url','kind','checked_at','observed_differences'])),JSON_UNESCAPED_UNICODE);return $safe;},$data['tasks']??[]);
        return $out;
    }
}

````

## app/Views/AiVisibility/index.php

````php
<?php
$geoLanguage=function_exists('current_lang')?(current_lang()==='ar'?'ar':'en'):'ar';
$geoMessages=require dirname(__DIR__,2).'/Lang/ai_visibility_'.$geoLanguage.'.php';
$geoTranslate=static fn(string $key):string=>$geoMessages[$key]??$key;
?>
<style>
#geo-root{--geo-border:var(--panel-border,#29354b);padding:clamp(14px,3vw,26px);color:var(--panel-text,#f2f4f8);line-height:1.7}#geo-root *{box-sizing:border-box}#geo-root [hidden]{display:none!important}.geo-head,.geo-actions,.geo-tabs{display:flex;align-items:center;gap:10px;flex-wrap:wrap;justify-content:space-between}.geo-head h2{margin:0 0 8px;font-size:clamp(20px,3vw,25px);line-height:1.6}.geo-muted{color:var(--panel-text-muted,#a5aec1);line-height:1.8}.geo-filters,.geo-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:20px 0}#geo-root label{display:block}#geo-root select,#geo-root textarea{width:100%;margin-top:8px;max-width:100%;font:inherit}#geo-root textarea{min-height:90px;resize:vertical;padding:12px}.geo-next,.geo-box{border:1px solid var(--geo-border);border-radius:12px;padding:18px;margin:14px 0}.geo-next{border-inline-start:4px solid #818cf8}.geo-next h3,.geo-box h3{margin:0 0 10px}.geo-tabs{justify-content:flex-start;border-bottom:1px solid var(--geo-border);padding:14px 0;margin-bottom:18px}.geo-tabs [aria-selected=true]{background:#465cc9;color:#fff}.geo-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.geo-stat{font-size:26px;font-weight:700;margin:12px 0}.geo-question{margin:12px 0}.geo-check{display:flex!important;align-items:center;gap:8px;margin:12px 0}.geo-check input{width:auto}#geo-message{padding:12px;border:1px solid var(--geo-border);border-radius:8px;white-space:pre-wrap}#geo-message[data-error=true]{border-color:#d68472}.geo-scroll{overflow:auto}#geo-root table{min-width:540px;width:100%}#geo-root td{max-width:340px;overflow-wrap:anywhere;white-space:pre-wrap}#geo-root summary{cursor:pointer;padding:10px 0}#geo-root button:disabled{opacity:.5;cursor:wait}#geo-root a:focus-visible,#geo-root button:focus-visible{outline:2px solid #a5b4fc;outline-offset:3px}.geo-empty{padding:24px 12px;text-align:center;line-height:1.9;border:1px dashed var(--geo-border);border-radius:10px}.geo-actions{justify-content:flex-start}#geo-llms-draft{white-space:pre-wrap;overflow-wrap:anywhere}@media(max-width:640px){.geo-filters,.geo-grid{grid-template-columns:1fr}.geo-head{align-items:flex-start}.geo-tabs button{flex:1;padding:10px 6px}.geo-actions .p-btn{width:100%}}
</style>
<section class="p-card" dir="<?= $geoLanguage==='ar'?'rtl':'ltr' ?>" id="geo-root" data-csrf="<?= htmlspecialchars(Csrf::token(), ENT_QUOTES, 'UTF-8') ?>">
<div class="geo-head"><div><h2><?= htmlspecialchars($geoTranslate('هل بيظهر اسم شركتك في إجابات الذكاء الاصطناعي؟'), ENT_QUOTES, 'UTF-8') ?></h2><div class="geo-muted"><?= htmlspecialchars($geoTranslate('راجع أسئلة عملائك، وافق على قياسها، وتابع النتائج ومصادرها.'), ENT_QUOTES, 'UTF-8') ?></div></div><button type="button" class="p-btn outline" id="geo-reload"><?= htmlspecialchars($geoTranslate('تحديث النتائج'), ENT_QUOTES, 'UTF-8') ?></button></div>
<div class="geo-filters"><label for="geo-site"><?= htmlspecialchars($geoTranslate('١. اختار موقعك'), ENT_QUOTES, 'UTF-8') ?><select class="p-select" id="geo-site" disabled><option value=""><?= htmlspecialchars($geoTranslate('جارٍ تحميل المواقع…'), ENT_QUOTES, 'UTF-8') ?></option></select></label><label for="geo-market"><?= htmlspecialchars($geoTranslate('٢. اختار البلد واللغة'), ENT_QUOTES, 'UTF-8') ?><select class="p-select" id="geo-market" disabled><option value=""><?= htmlspecialchars($geoTranslate('اختار الموقع الأول'), ENT_QUOTES, 'UTF-8') ?></option></select></label></div>
<p id="geo-message" role="status" aria-live="polite" hidden></p>
<article class="geo-next"><h3 id="geo-next-title"><?= htmlspecialchars($geoTranslate('جارٍ تجهيز حسابك'), ENT_QUOTES, 'UTF-8') ?></h3><p id="geo-state" class="geo-muted"><?= htmlspecialchars($geoTranslate('بنحمّل المواقع والأسواق المتاحة…'), ENT_QUOTES, 'UTF-8') ?></p><div class="geo-actions" id="geo-next-actions"></div></article>
<div id="geo-content" hidden>
<div class="geo-tabs" role="tablist" aria-label="<?= htmlspecialchars($geoTranslate('متابعة ظهور الشركة'), ENT_QUOTES, 'UTF-8') ?>"><button type="button" class="p-btn outline" id="geo-tab-results" role="tab" aria-controls="geo-pane-results" aria-selected="true" tabindex="0"><?= htmlspecialchars($geoTranslate('النتائج'), ENT_QUOTES, 'UTF-8') ?></button><button type="button" class="p-btn outline" id="geo-tab-questions" role="tab" aria-controls="geo-pane-questions" aria-selected="false" tabindex="-1"><?= htmlspecialchars($geoTranslate('الأسئلة'), ENT_QUOTES, 'UTF-8') ?></button><button type="button" class="p-btn outline" id="geo-tab-settings" role="tab" aria-controls="geo-pane-settings" aria-selected="false" tabindex="-1"><?= htmlspecialchars($geoTranslate('بيانات الشركة'), ENT_QUOTES, 'UTF-8') ?></button></div>
<section id="geo-pane-results" role="tabpanel" aria-labelledby="geo-tab-results"><h3><?= htmlspecialchars($geoTranslate('أحدث قياسات ظهور شركتك'), ENT_QUOTES, 'UTF-8') ?></h3><div id="geo-cards" class="geo-grid"></div><p id="geo-coverage" class="geo-muted"></p><div class="geo-box"><h3><?= htmlspecialchars($geoTranslate('الإجابات والمصادر'), ENT_QUOTES, 'UTF-8') ?></h3><p class="geo-muted"><?= htmlspecialchars($geoTranslate('راجع مقتطف الإجابة وروابط المصادر للتأكد من النتيجة.'), ENT_QUOTES, 'UTF-8') ?></p><div id="geo-answers" class="geo-scroll"></div></div><details class="geo-box"><summary><?= htmlspecialchars($geoTranslate('تطور النتائج خلال آخر ٨ أسابيع'), ENT_QUOTES, 'UTF-8') ?></summary><div id="geo-trend" class="geo-scroll"></div></details><details class="geo-box"><summary><?= htmlspecialchars($geoTranslate('اقتراحات تحسين مبنية على النتائج'), ENT_QUOTES, 'UTF-8') ?></summary><div id="geo-tasks" class="geo-scroll"></div></details><p class="geo-muted"><?= htmlspecialchars($geoTranslate('القياس عينة من إجابات البحث في وقت محدد، مش ضمان ظهور في تطبيقات الشات. ترتيب الاسم محسوب وسط الشركات المتابَعة فقط.'), ENT_QUOTES, 'UTF-8') ?></p></section>
<section id="geo-pane-questions" role="tabpanel" aria-labelledby="geo-tab-questions" hidden><div class="geo-head"><div><h3><?= htmlspecialchars($geoTranslate('٣. راجع الأسئلة ووافق على اللي يناسبك'), ENT_QUOTES, 'UTF-8') ?></h3><p class="geo-muted"><?= htmlspecialchars($geoTranslate('الأسئلة بتتجهّز من كلمات البحث الحقيقية. كل سؤال لازم تحفظ موافقتك عليه عشان يدخل القياس الأسبوعي.'), ENT_QUOTES, 'UTF-8') ?></p></div><button type="button" class="p-btn" id="geo-generate"><?= htmlspecialchars($geoTranslate('تجهيز أسئلة مقترحة'), ENT_QUOTES, 'UTF-8') ?></button></div><p id="geo-question-count" class="geo-muted"></p><div id="geo-questions"></div><a class="p-btn outline" id="geo-keywords" href="/keywords"><?= htmlspecialchars($geoTranslate('إدارة الأسواق وكلمات البحث'), ENT_QUOTES, 'UTF-8') ?></a></section>
<section id="geo-pane-settings" role="tabpanel" aria-labelledby="geo-tab-settings" hidden><h3><?= htmlspecialchars($geoTranslate('أكد هوية شركتك'), ENT_QUOTES, 'UTF-8') ?></h3><p class="geo-muted"><?= htmlspecialchars($geoTranslate('ابدأ بتأكيد الاسم والخدمات من بيانات الشركة. الأسماء البديلة والروابط هنا بتساعدنا نميّز شركتك عن الشركات المشابهة.'), ENT_QUOTES, 'UTF-8') ?></p><a href="/business-hub" class="p-btn outline"><?= htmlspecialchars($geoTranslate('مراجعة بيانات الشركة'), ENT_QUOTES, 'UTF-8') ?></a><form id="geo-identity" class="geo-box"><label for="geo-aliases"><?= htmlspecialchars($geoTranslate('أسماء بديلة لشركتك بالعربي أو الإنجليزي'), ENT_QUOTES, 'UTF-8') ?><textarea class="p-select" id="geo-aliases" name="aliases" maxlength="1000" placeholder="<?= htmlspecialchars($geoTranslate('اسم واحد في كل سطر'), ENT_QUOTES, 'UTF-8') ?>"></textarea></label><label for="geo-profiles"><?= htmlspecialchars($geoTranslate('روابط صفحات شركتك الرسمية'), ENT_QUOTES, 'UTF-8') ?><textarea class="p-select" id="geo-profiles" name="profiles" maxlength="10000" placeholder="<?= htmlspecialchars($geoTranslate('رابط كامل في كل سطر'), ENT_QUOTES, 'UTF-8') ?>"></textarea></label><p class="geo-muted"><?= htmlspecialchars($geoTranslate('تغيير الهوية يحتاج مراجعة الأسئلة والموافقة عليها من جديد.'), ENT_QUOTES, 'UTF-8') ?></p><button class="p-btn"><?= htmlspecialchars($geoTranslate('حفظ الأسماء والروابط'), ENT_QUOTES, 'UTF-8') ?></button></form><details class="geo-box"><summary><?= htmlspecialchars($geoTranslate('اختياري: مسودة تعريف الموقع لمحركات الذكاء الاصطناعي'), ENT_QUOTES, 'UTF-8') ?></summary><p class="geo-muted"><?= htmlspecialchars($geoTranslate('جهّز مسودة llms.txt من صفحات موقعك العامة. راجعها قبل النشر؛ الزر ده مش بينشرها على موقعك.'), ENT_QUOTES, 'UTF-8') ?></p><button type="button" class="p-btn outline" id="geo-llms"><?= htmlspecialchars($geoTranslate('تجهيز المسودة'), ENT_QUOTES, 'UTF-8') ?></button><pre id="geo-llms-draft"></pre></details></section>
</div></section>
<script>
(()=>{const start=()=>{const translations=<?= json_encode($geoMessages, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE) ?>,t=key=>translations[key]??key;const el=id=>document.getElementById('geo-'+id);if(!el('root')||!window.Panel)return;let data=null,busy=false,sitesLoaded=false,active='results';const root=el('root'),rows=v=>Array.isArray(v)?v:[],labels={openai:'ChatGPT',gemini:'Gemini',perplexity:'Perplexity'},base=()=>({website_id:Number(el('site').value),market_id:Number(el('market').value)}),visible=r=>Number(r.market_id)===base().market_id;
const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
const parsed=(v,fallback)=>{if(v&&typeof v==='object')return v;try{const r=JSON.parse(v);return r&&typeof r==='object'?r:fallback;}catch{return fallback;}};
const message=(text,error=false)=>{el('message').textContent=text;el('message').hidden=!text;el('message').dataset.error=String(error);};
function gate(){root.setAttribute('aria-busy',String(busy));root.querySelectorAll('button,input,textarea,select').forEach(c=>c.disabled=busy);el('site').disabled=busy||!el('site').value;el('market').disabled=busy||!data||!el('market').value;for(const id of ['generate','llms'])el(id).disabled=busy||!data||!base().market_id;el('reload').textContent=busy?t('جارٍ التحميل…'):t('تحديث النتائج');}
function tab(name,focus=false){active=name;for(const key of ['results','questions','settings']){el('pane-'+key).hidden=key!==name;el('tab-'+key).setAttribute('aria-selected',String(key===name));el('tab-'+key).tabIndex=key===name?0:-1;}if(focus)el('tab-'+name).focus();}
for(const name of ['results','questions','settings'])el('tab-'+name).onclick=()=>tab(name);
root.querySelector('[role=tablist]').onkeydown=e=>{const names=['results','questions','settings'];if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const i=names.indexOf(active);tab(e.key==='Home'?names[0]:e.key==='End'?names[2]:names[(i+(e.key==='ArrowLeft'?1:2))%3],true);};
function action(label,fn,href){const n=node(href?'a':'button',label,'p-btn outline');if(href)n.href=href;else{n.type='button';n.onclick=fn;}el('next-actions').append(n);}
function next(title,text){el('next-title').textContent=title;el('state').textContent=text;el('next-actions').replaceChildren();}
async function request(path,body){const r=await window.Panel.fetchJSON('/api/ai-visibility/'+path+(body===undefined?'?'+new URLSearchParams(base()):''),body===undefined?undefined:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...base(),...body,csrf_token:root.dataset.csrf})});if(!r?.success)throw Error(r?.error||r?.message||t('تعذر إتمام الطلب. حاول تاني.'));return r.data;}
async function work(fn,success=''){if(busy)return;busy=true;message('');gate();try{await fn();if(success)message(success);}catch(e){message(e.message||t('تعذر إتمام الطلب. حاول تاني.'),true);if(!data){next(t('تعذر تحميل البيانات'),t('اختيار موقعك محفوظ. اضغط تحديث النتائج لإعادة المحاولة.'));action(t('إعادة المحاولة'),()=>work(load));}}finally{busy=false;gate();}}
function empty(dest,text){dest.replaceChildren(node('p',text,'geo-empty'));}
function table(id,list,cols,emptyText){const dest=el(id);if(!list.length){empty(dest,emptyText);return;}const t=node('table',undefined,'p-table'),tr=t.createTHead().insertRow();cols.forEach(c=>{const th=node('th',c[1]);th.scope='col';tr.append(th);});const body=t.createTBody();list.forEach(r=>{const tr=body.insertRow();cols.forEach(c=>{const td=tr.insertCell(),v=typeof c[0]==='function'?c[0](r):r[c[0]];if(v instanceof Node)td.append(v);else td.textContent=String(v??t('غير متاح'));});});dest.replaceChildren(t);}
const pct=v=>v===null||v===undefined||!Number.isFinite(Number(v))?t('غير مقاس'):(Number(v)*100).toFixed(1)+'%';
function sources(value){const box=node('div');for(const raw of rows(parsed(value,[]))){try{const u=new URL(typeof raw==='string'?raw:raw.url);if(!['https:','http:'].includes(u.protocol))continue;const a=node('a',u.hostname);a.href=u.href;a.target='_blank';a.rel='noopener noreferrer';box.append(a,node('br'));}catch{}}if(!box.childNodes.length)box.textContent=t('مفيش مصدر متاح');return box;}
function draw(){const qs=rows(data.questions).filter(visible),approved=qs.filter(q=>Number(q.approved)===1).length,metrics=rows(data.metrics).filter(visible),answers=rows(data.answers).filter(visible);const waiting=approved>0;
if(data.profile_state==='needs_confirmed_business_profile'){next(t('أكد بيانات الشركة الأول'),t('راجع اسم الشركة وخدماتها وروابطها الحالية، واحفظ تأكيدك قبل تجهيز الأسئلة.'));action(t('مراجعة بيانات الشركة'),null,'/business-hub');}
else if(!base().market_id){next(t('اختار سوق لموقعك'),t('حدد البلد واللغة من إدارة الأسواق، وبعدها حدّث النتائج.'));action(t('إدارة الأسواق وكلمات البحث'),null,'/keywords?website_id='+base().website_id);}
else if(!qs.length){next(t('الخطوة التالية: جهّز أسئلة عملائك'),t('أكد بيانات الشركة وكلمات البحث الحقيقية، وبعدها جهّز الأسئلة وراجعها.'));action(t('مراجعة بيانات الشركة'),null,'/business-hub');action(t('تجهيز الأسئلة'),()=>{tab('questions');work(generate);});}
else if(!waiting){next(t('الخطوة التالية: راجع الأسئلة واحفظ موافقتك'),t('الأسئلة غير المعتمدة مش بتدخل القياس. اختار الأسئلة المناسبة واحفظ كل سؤال.'));action(t('مراجعة الأسئلة'),()=>tab('questions'));}
else if(!metrics.length){next(t('أسئلتك المعتمدة جاهزة للقياس الأسبوعي'),approved+t(' سؤال معتمد في السوق ده. النتائج هتظهر بعد تشغيل القياس المجدول؛ تحديث النتائج مش بيبدأ قياس جديد.'));action(t('مراجعة الأسئلة'),()=>tab('questions'));}
else{next(t('نتائج السوق متاحة للمراجعة'),t('راجع الإجابات ومصادرها. تحديث النتائج بيعرض أحدث قياسات محفوظة، ومش بيبدأ قياس جديد.'));action(t('عرض الإجابات والمصادر'),()=>{tab('results');el('answers').scrollIntoView({behavior:'smooth',block:'center'});});}
el('cards').replaceChildren();for(const [name,status] of Object.entries(data.providers||{})){const card=node('article',undefined,'geo-box'),m=metrics.find(x=>x.provider===name);card.append(node('h3',status?.label||labels[name]||t('خدمة بحث')));if(m){card.append(node('div',pct(m.share_of_voice),'geo-stat'),node('p',t('نسبة الإجابات اللي ذكرت شركتك')),node('p',t('اقتباس موقعك: ')+pct(m.citation_rate),'geo-muted'),node('p',m.questions+t(' إجابة مقاسة'),'geo-muted'),node('p',(m.week_start||'')+(m.stale?t(' — قياس قديم'):'')+(m.partial?t(' — عينة جزئية'):''),'geo-muted'));}else card.append(node('p',t('لسه مفيش قياسات محفوظة للسوق ده.'),'geo-muted'));el('cards').append(card);}if(!el('cards').children.length)empty(el('cards'),t('لسه مفيش نتائج لعرضها.'));
el('coverage').textContent=metrics.length?t('النسب من العينة المقاسة بتاريخها، مش من كل إجابات الخدمة.'):t('عدم وجود قياس مش معناه إن نسبة ظهورك صفر.');
el('question-count').textContent=qs.length?approved+t(' سؤال معتمد من ')+qs.length+t(' في السوق المختار.'):t('لسه مفيش أسئلة للسوق ده. جهّز كلمات البحث الحقيقية الأول، وبعدها اضغط تجهيز أسئلة مقترحة.');
el('questions').replaceChildren();if(data.question_mode==='set'){drawSet();}else qs.forEach((q,i)=>{const box=node('article',undefined,'geo-box geo-question'),label=node('label',t('السؤال ')+(i+1)),input=node('textarea',undefined,'p-select'),check=node('input'),approval=node('label',undefined,'geo-check'),button=node('button',t('حفظ السؤال'),'p-btn');input.id='geo-question-'+q.id;label.htmlFor=input.id;input.value=q.question||'';input.maxLength=1000;input.required=true;check.type='checkbox';check.checked=Number(q.approved)===1;approval.append(check,document.createTextNode(t('موافق على قياس السؤال أسبوعيًا')));button.type='button';input.oninput=()=>{button.textContent=t('حفظ التغييرات');};check.onchange=()=>{button.textContent=t('حفظ التغييرات');};button.onclick=()=>work(async()=>{if(!input.value.trim())throw Error(t('اكتب السؤال قبل الحفظ.'));await request('question',{id:Number(q.id),question:input.value.trim(),approved:check.checked});await load();},t('تم حفظ السؤال وموقف الموافقة.'));box.append(label,input,approval,button);el('questions').append(box);});if(!qs.length&&data.question_mode!=='set')empty(el('questions'),t('ابدأ بتجهيز الأسئلة من كلمات البحث، وبعدها هتظهر هنا للمراجعة.'));
table('answers',answers,[[r=>labels[r.provider]||t('خدمة بحث'),t('الخدمة')],['question',t('السؤال')],[r=>Number(r.mentioned_brand)?t('تم ذكر الشركة'):t('لم تُذكر الشركة'),t('ذكر شركتك')],[r=>r.cited_domain==null?t('غير مقاس'):Number(r.cited_domain)?t('تم الاقتباس'):t('لم يتم الاقتباس'),t('اقتباس موقعك')],[r=>sources(r.cited_urls),t('المصادر')],['answer_excerpt',t('مقتطف الإجابة')],['checked_at',t('تاريخ القياس')]],t('بعد أول قياس، الإجابات ومصادرها هتظهر هنا.'));
const trend=[];rows(data.trend).forEach(w=>rows(w.providers).filter(visible).forEach(p=>trend.push({...p,week:w.week})));table('trend',trend,[['week',t('الأسبوع')],[r=>labels[r.provider]||t('خدمة بحث'),t('الخدمة')],[r=>pct(r.share_of_voice),t('نسبة الذكر')],[r=>pct(r.citation_rate),t('الاقتباس')]],t('اتجاه النتائج بيتكوّن مع تراكم القياسات الأسبوعية.'));
table('tasks',rows(data.tasks),[['title',t('المهمة')],['instructions',t('خطوات المراجعة')],[r=>sources([parsed(r.evidence_json,{}).url].filter(Boolean)),t('المصدر')],[r=>({pending:t('للمراجعة'),verified:t('تم التحقق'),done:t('مكتملة'),dismissed:t('تم استبعادها'),applied:t('تم التطبيق')}[r.status]||t('للمراجعة')),t('الحالة')]],t('مفيش اقتراحات تحسين متاحة حاليًا.'));if(data.question_mode==='set')el('pane-questions').querySelector('.geo-head p').textContent=t('الموافقة بتخص قائمة الأسئلة كاملة. راجع النصوص واحفظ القائمة بعد أي تعديل.');
let confirmation=el('entity-confirm');if(!confirmation){const label=node('label',undefined,'geo-check');confirmation=node('input');confirmation.type='checkbox';confirmation.id='geo-entity-confirm';label.append(confirmation,document.createTextNode(t('أؤكد أن أسماء الشركة وروابطها صحيحة.')));el('identity').insertBefore(label,el('identity').querySelector('button'));}confirmation.checked=false;confirmation.parentElement.hidden=data.question_mode!=='set';
el('identity').elements.aliases.value=(data.identity_aliases||rows(data.aliases).slice(1)).join('\n');el('identity').elements.profiles.value=rows(data.profile_urls).join('\n');el('keywords').href='/keywords?website_id='+base().website_id;el('content').hidden=false;tab(active);}
async function load(){data=null;el('content').hidden=true;el('llms-draft').textContent='';next(t('جارٍ تحميل حالة الموقع'),t('بنحمّل الأسواق والأسئلة والقياسات المحفوظة…'));if(!sitesLoaded){const r=await window.Panel.fetchJSON('/api/websites');if(!r?.success)throw Error(r?.error||t('تعذر تحميل المواقع.'));const sites=rows(r.data?.websites||r.data?.items||r.data);const previous=el('site').value||new URLSearchParams(location.search).get('website_id');el('site').replaceChildren(...sites.map(s=>new Option(s.name||s.domain||s.main_url||s.url||t('موقعي'),s.id)));if(sites.some(s=>String(s.id)===previous))el('site').value=previous;sitesLoaded=true;}if(!base().website_id){sitesLoaded=false;next(t('أضف موقعك عشان تبدأ'),t('اربط موقعك بحسابك، وبعدها ارجع هنا لاختيار السوق وتجهيز الأسئلة.'));action(t('إدارة المواقع'),null,'/websites');return;}const previous=el('market').value;el('market').replaceChildren(new Option(t('جارٍ تحميل الأسواق…'),''));try{data=await request('overview');}catch(e){el('market').replaceChildren(new Option(t('تعذر تحميل الأسواق'),''));throw e;}const markets=rows(data.markets);el('market').replaceChildren(...markets.map(m=>new Option(m.label,m.id)));if(markets.some(m=>String(m.id)===previous))el('market').value=previous;if(!markets.length)el('market').append(new Option(t('مفيش سوق مضاف'),''));draw();}
function drawSet(){el('questions').replaceChildren();const set=data.question_set||{version:0,questions:[]},draft=Array.isArray(data.draft_questions)?data.draft_questions:null,box=node('form',undefined,'geo-box'),label=node('label',t('قائمة الأسئلة — سؤال واحد في كل سطر')),input=node('textarea',undefined,'p-select'),approval=node('label',undefined,'geo-check'),check=node('input'),button=node('button',t('حفظ القائمة'),'p-btn');input.id='geo-question-set';input.rows=14;input.maxLength=9500;input.value=(draft||set.questions||[]).join('\n');label.htmlFor=input.id;check.type='checkbox';check.id='geo-set-approve';check.checked=!draft&&Boolean(set.approved_at);approval.append(check,document.createTextNode(t('راجعت القائمة كاملة وأوافق على قياسها أسبوعيًا')));const hint=node('p',t('راجع من 10 إلى 30 سؤالًا بدون اسم شركتك. الموافقة بتخص القائمة كاملة، وأي تعديل يحتاج مراجعتها.'),'geo-muted');input.oninput=()=>{check.checked=false;};box.append(label,input,hint,approval,button);box.onsubmit=e=>{e.preventDefault();const questions=input.value.split('\n').map(x=>x.trim()).filter(Boolean);work(async()=>{if(questions.length<10||questions.length>30)throw Error(t('احفظ من 10 إلى 30 سؤالًا في القائمة.'));await request('question',{questions,version:Number(set.version||0),approved:check.checked});await load();},t('تم حفظ القائمة وموقف الموافقة.'));};el('questions').append(box);}
async function generate(){const result=await request('generate',{});if(Array.isArray(result.draft_questions)){data.draft_questions=result.draft_questions;data.question_set={...(data.question_set||{}),version:result.set_version};tab('questions');drawSet();gate();}else await load();}
el('site').onchange=()=>{el('market').replaceChildren();work(load);};el('market').onchange=()=>{message('');el('llms-draft').textContent='';draw();gate();};el('reload').onclick=()=>work(load);el('generate').onclick=()=>work(generate,t('اتجهزت مسودة الأسئلة. راجع كل سؤال واحفظ موافقتك.'));el('identity').onsubmit=e=>{e.preventDefault();const f=e.target.elements,lines=v=>v.split('\n').map(x=>x.trim()).filter(Boolean);work(async()=>{if(data.question_mode==='set'&&!el('entity-confirm').checked)throw Error(t('أكد صحة أسماء الشركة وروابطها قبل الحفظ.'));await request('identity',{aliases:lines(f.aliases.value),profile_urls:lines(f.profiles.value),...(data.question_mode==='set'?{version:data.entity_version,confirmed:true,address:data.entity_address||''}:{})});await load();},t('تم حفظ هوية الشركة. راجع الأسئلة واحفظ موافقتك عليها من جديد.'));};el('llms').onclick=()=>work(async()=>{const r=await request('llms',{});el('llms-draft').textContent=(r.draft||'')+'\n\n'+(r.note||r.publication||t('راجع المسودة قبل النشر.'));},t('المسودة جاهزة للمراجعة، ولم يتم نشرها.'));work(load);
};if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();})();
</script>

````

## docs/seo/package-compatibility-review.md

````markdown
# Uploaded SEO package: compatibility review and correction

Date: 2026-10-17 (Africa/Cairo). Branch: `fix/seo-package-contract-compatibility`.

## Scope and assumption

The user supplied architecture and hard rules but no numbered feature prompt or acceptance list. After “متابعة”, the selected scope is to review the supplied package and correct proven AI visibility integration defects, retaining existing SEO execution and billing. This is not delivery or certification of the whole SEO roadmap. Risk tier definitions were not supplied, so no new automatic permission tier or live-site execution is introduced.

The ZIP was extracted separately and not copied over the checkout. Its PHP files passed syntax checks: 192/192. The snapshot has 46 files absent from the checkout, 57 differing files and 125 identical files (excluding directory entries). This divergence explains why mixing entire release maps or service implementations is inappropriate. Syntax checks are not functional validation.

## Design and exact file list

Production:
- CHANGE `app/Controllers/AiVisibilityController.php`: dispatch to the installed contract; preserve authenticated index/page and CSRF handling. Modern requests use whole-list `save`, `entities` and service-owned `llmsDraft`; legacy calls remain available. Pass selected market to modern overview and obtain owned markets through existing service. Draft generation never saves or approves questions. Add save/entities action aliases without replacing route files. Reject missing identity confirmation or question-list version. Delegate stale-version rejection and ownership enforcement to existing services.
- CHANGE `app/Services/AiVisibility/AiVisibilityPresentation.php`: normalize the current package response before applying customer allowlists. Retain actual rates, sample counts, dated samples, stale/partial flags and nullable citation values. Exclude empty trend observations rather than inventing zeroes. Keep set and identity versions for safe writes. Supply market identity on market-scoped answer rows. Continue excluding provider configuration, models, costs and internal evidence.
- CHANGE `app/Views/AiVisibility/index.php`: support whole-list review for current service and existing individual-question review for legacy service; draft generation remains unsaved. Editing a current list clears the approval checkbox; require explicit identity confirmation. Preserve saved address and identity version. Display dated/stale/partial samples. Retain guided tabs, mobile behavior, retry handling and safe source links. Load translations according to existing `current_lang()`; use English fallback for other supported UI languages.
- ADD `app/Lang/ai_visibility_ar.php`.
- ADD `app/Lang/ai_visibility_en.php`.

Verification and documentation:
- ADD `tests/Unit/SeoPackageCompatibilityTest.php`.
- ADD `tests/Fixtures/Seo/controller_contract_probe.php` (offline fixture only; never deploy as an endpoint).
- CHANGE `tests/Automation/ai_visibility_ui_browser_test.py`.
- ADD `docs/seo/package-compatibility-review.md` (this file).

No new production class is added. No release classmap replacement, route-file replacement, provider client replacement, database change, dependency change or cron configuration is included.

## Proven defects

1. In the uploaded package, the controller invoked `saveQuestion` and `identity`, whereas its service exposes `save` and `entities` with versioned approval. Its llms endpoint also referenced a different service path.
2. Modern metrics contain scalar metadata plus a `providers` object. The previous projection treated metrics as a list; filtering malformed rows alone prevented exceptions but could discard actual measurements and their structure.
3. Overview returns `market`, `prompt_set`, and `entities`; older UI requires markets and questions. Mixing those contracts produced empty selectors and unusable editing controls.
4. Whole-list approval cannot safely be represented by arbitrary per-question IDs. This patch shows the actual approval boundary instead of emulating unsupported individual consent.

## SQL migration

Not applicable: this correction adds no table, column or stored data format. There is intentionally no SQL file to run. Existing SEO/GEO migrations required by the deployed service must already be installed. This ZIP is not a substitute for an initial installation or missing phase migrations.

## Tests and exact commands

```sh
php -l app/Controllers/AiVisibilityController.php
php -l app/Services/AiVisibility/AiVisibilityPresentation.php
php -l app/Views/AiVisibility/index.php
php -l app/Lang/ai_visibility_ar.php
php -l app/Lang/ai_visibility_en.php
vendor/bin/phpunit --no-configuration --bootstrap tests/Unit/offline_bootstrap.php tests/Unit/SeoPackageCompatibilityTest.php
python3 tests/Automation/ai_visibility_ui_browser_test.py
php tests/Automation/ai_visibility_page_compatibility_test.php
php tests/Automation/ai_visibility_error_logging_test.php
php tests/Automation/ai_visibility_projection_shapes_test.php
php tests/Automation/admin_connections_customer_test.php
```

Results: PHPUnit 5 tests / 25 assertions; browser 8 scenarios; existing regression scripts 5/5, 3/3, 17/17 and 26/26. Browser fixtures simulate both payload contracts and responses; they make no paid provider calls. PHPUnit controller probe verifies delegation, drafts not saved implicitly, required confirmation, explicit approval/version forwarding, and propagation of version conflict. It uses a fresh PHP process with `-n` because the fixture requires no PHP extensions or application configuration. This is not a database concurrency stress test.

## Deployment and rollback

1. Back up the five production paths listed above. Record which dictionary files did not previously exist.
2. Upload only the production ZIP over the current installation, preserving paths. Keep tests, full-code listing and documentation off the public web root.
3. Invalidate hosting OPcache if enabled, then reload `/ai-visibility`.
4. Test as a customer: select an owned website and market; generate a draft; verify it is not approved or saved automatically; review and save 10–30 questions with explicit list approval; edit again and verify approval is cleared; reload and confirm saved state; review identity and confirm before saving; review actual source/date/sample size when data exists.
5. Test a second browser session: load the same set in both sessions; save in the first; saving the stale second copy must be rejected by the service rather than replacing newer data.
6. Test Arabic and English, a customer with no website, API failure/retry, and a second website with different questions. Confirm no API keys, provider models, configuration or provider billing fields appear.
7. No new provider/admin setting or API key is required for this patch. Existing providers and scheduled jobs retain their configuration.

Rollback: restore the backed-up production files together and invalidate OPcache. Delete new dictionaries only after restoring the view that no longer references them. There is no database rollback. Lists and identities deliberately saved by customers through the existing services remain stored; rolling back PHP files does not undo those customer actions. This correction does not touch the live customer website or change SEO execution policy.

## Acceptance evidence for this correction

- [x] Modern whole-list and legacy individual-question contracts are distinguished.
- [x] Real rates, nullable citation results, sample counts and dates survive projection.
- [x] No unmeasured observation becomes an invented zero.
- [x] Customer payload excludes internal provider readiness, models, costs and setup instructions.
- [x] Current service receives selected market, user/site identity and optimistic version.
- [x] Draft generation does not imply approval or persistence.
- [x] Whole-list editing clears frontend approval; saving passes explicit consent.
- [x] Identity updates require confirmation, carry version and retain existing address.
- [x] Arabic/English dictionaries have matching keys; English uses LTR.
- [x] Offline tests, mobile UI, safe links and failure/retry checked locally.
- [x] No paid call, DDL, live-site mutation or new automation permission introduced.
- [ ] Live hosting, WordPress execution/rollback, real providers, shared-host worker timing and real GSC/GA4/billing integration are not verified by this correction.

## Other findings to address separately

The following are observed source-level issues, not fixed or certified here:
- `AiVisibilityService::run` has a 130-second work threshold and `AiVisibilityCheckJob` requests 240 seconds. `SeoExpertService` includes 65-second crawl and 150-second technical-check windows; `SeoWorkWindow` defaults to 65 seconds. These do not establish compliance with an approximately 60-second hosting ceiling. Correct treatment requires resumable boundaries and transport deadlines, not merely reducing a timer.
- The supplied snapshot excludes route registration, release map, most application configuration/i18n helpers and customer view files. Full deployed-route and application startup compatibility cannot be proved from this snapshot alone. The patch preserves existing route files.
- Several existing SQL statements rely on prior ownership checks and globally unique IDs rather than repeating both `user_id` and `website_id` in every statement. The strict query-scoping rule is not certified for the whole supplied codebase. This correction adds no SQL statements.
- The supplied `tests/Unit/phpunit.xml` references directories relative to its location that do not match the snapshot layout, and its normal bootstrap expects omitted application config. The targeted offline command above bypasses that configuration without disabling assertions.
- Existing live-change validation, reversibility, monthly caps, queue idempotency, prompt-injection controls, plugin signatures and measured business impact were not reimplemented or comprehensively audited in this limited fix.

````

## tests/Automation/ai_visibility_ui_browser_test.py

````python
"""Offline UI contract check. Requires PHP, Playwright Python and Chromium (development only)."""
import json, subprocess, os
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
view=root/'app/Views/AiVisibility/index.php'
html=subprocess.check_output(['php','-r',"class Csrf {static function token(){return 'fixture-csrf';}} require $argv[1];",str(view)],text=True)
panel_css=(root/'public_html/assets/css/panel.css').read_text()
html='<style>'+panel_css+'</style>'+html
html='<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><script>window.Panel={fetchJSON:async(u,o)=>{const r=await fetch(u,o);return r.json();}};</script>'+html+'</html>'
origin='https://ui.example.test'
state={'fail':False,'empty':False,'questions':[],'posts':[],'metrics':[]}
def payload(wid):
 if state.get('current'):
  return {'state':'not_measured','providers':{'openai':{'label':'ChatGPT'}},'markets':[{'id':wid*10,'label':'Egypt – English'}],'questions':[],'metrics':[],'answers':[],'trend':[],'tasks':[],'question_mode':'set','question_set':state['set'],'entity_version':2,'entity_address':'Confirmed address','identity_aliases':['Example'],'aliases':['Example'],'profile_urls':[]}
 return {'state':'not_measured','providers':{'openai':{'label':'ChatGPT'}},'markets':[{'id':wid*10,'label':'مصر — العربية'}], 'questions':state['questions'] if wid==1 else [],'metrics':state['metrics'],'answers':state.get('answers',[]), 'trend':[], 'tasks':[], 'aliases':['Example','Example Tours'],'profile_urls':['https://example.com']}
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.getenv('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 def handle(route):
  req=route.request;u=req.url
  if u==origin+'/':route.fulfill(status=200,content_type='text/html',body=html);return
  if '/api/websites' in u:route.fulfill(json={'success':True,'data':{'websites':[] if state['empty'] else [{'id':1,'main_url':'https://example.com'},{'id':2,'main_url':'https://second.example.com'}]}});return
  if '/api/ai-visibility/' in u:
   from urllib.parse import urlparse,parse_qs
   if req.method=='POST':
    body=req.post_data_json;state['posts'].append((u,body))
    if u.endswith('/generate') and state.get('current'):
     route.fulfill(json={'success':True,'data':{'draft_questions':['What can I compare for tour option '+str(i)+'?' for i in range(10)],'set_version':4,'market_id':10}});return
    if u.endswith('/question') and state.get('current'):
     assert body['version']==state['set']['version']
     state['set']={'version':5,'questions':body['questions'],'approved_at':'2026-10-17' if body['approved'] else None}
     route.fulfill(json={'success':True,'data':{'saved':True}});return
    if u.endswith('/generate'):state['questions']=[{'id':3,'market_id':10,'question':'ما الخدمات المتاحة؟','approved':0}]
    if u.endswith('/question'):state['questions']=[{'id':3,'market_id':10,'question':body['question'],'approved':int(body['approved'])}]
    route.fulfill(json={'success':True,'data':{}});return
   if state['fail']:route.fulfill(status=503,json={'success':False,'error':'تعذر تحميل البيانات، حاول تاني'});return
   wid=int(parse_qs(urlparse(u).query)['website_id'][0]);route.fulfill(json={'success':True,'data':payload(wid)});return
  route.abort()
 page.route('**/*',handle)
 page.goto(origin+'/');page.wait_for_selector('#geo-content',state='visible')
 assert 'جهّز أسئلة' in page.locator('#geo-next-title').inner_text(), page.locator('#geo-root').inner_text()
 assert page.locator('#geo-generate').is_hidden()
 page.locator('#geo-tab-questions').click();page.locator('#geo-generate').click();page.wait_for_selector('#geo-question-3')
 page.locator('#geo-question-3').fill('كيف أحجز رحلة مؤكدة؟');page.locator('.geo-question input[type=checkbox]').check();page.locator('.geo-question button').click()
 page.wait_for_function("document.querySelector('#geo-next-title').textContent.includes('جاهزة')")
 body=state['posts'][-1][1];assert body['approved'] is True and body['website_id']==1 and body['market_id']==10 and body['csrf_token']=='fixture-csrf'
 assert 'مش بيبدأ قياس جديد' in page.locator('#geo-state').inner_text()
 print('PASS generate, edit and approve question with market, site and CSRF; scheduled measurement explained')
 page.locator('#geo-tab-settings').click();page.locator('#geo-aliases').fill('Example Tours\nمثال');page.locator('#geo-identity button').click();page.wait_for_function("document.querySelector('#geo-reload').disabled===false")
 assert state['posts'][-1][1]['aliases']==['Example Tours','مثال']
 print('PASS identity form saves without triggering measurement')
 state['metrics']=[{'provider':'openai','market_id':10,'share_of_voice':.5,'citation_rate':None,'questions':2}]
 state['answers']=[{'provider':'openai','market_id':10,'question':'<img src=x onerror=alert(1)>','mentioned_brand':1,'cited_domain':None,'cited_urls':'["javascript:alert(1)","https://example.com/source"]','answer_excerpt':'<script>alert(1)</script>','checked_at':'2026-10-17'}]
 page.locator('#geo-reload').click();page.wait_for_function("document.querySelector('#geo-next-title').textContent.includes('متاحة')")
 page.locator('#geo-tab-results').click()
 assert '50.0%' in page.locator('#geo-cards').inner_text()
 assert page.locator('#geo-answers img, #geo-answers script').count()==0
 assert page.locator('#geo-answers a').count()==1
 assert page.locator('#geo-answers a').get_attribute('href')=='https://example.com/source'
 assert 'غير مقاس' in page.locator('#geo-cards').inner_text()
 assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
 screenshot=os.getenv('GEO_SCREENSHOT_PATH')
 if screenshot:page.screenshot(path=screenshot,full_page=True)
 print('PASS real metrics remain visible, unmeasured citations stay distinct, source links reject script URLs and text is escaped')
 state['fail']=True;page.locator('#geo-reload').click();page.wait_for_selector('#geo-message[data-error=true]')
 assert page.locator('#geo-content').is_hidden() and page.locator('#geo-site').input_value()=='1'
 assert page.locator('#geo-generate').is_disabled()
 state['fail']=False;page.locator('#geo-next-actions button').click();page.wait_for_selector('#geo-content',state='visible')
 print('PASS API error preserves site, hides stale content and supports retry')
 page.locator('#geo-site').select_option('2');page.wait_for_function("document.querySelector('#geo-market').value==='20' && document.querySelector('#geo-reload').disabled===false")
 page.locator('#geo-tab-questions').click();assert page.locator('.geo-question').count()==0
 assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'Mobile horizontal overflow'
 page.locator('#geo-tab-questions').focus();page.keyboard.press('ArrowLeft');assert page.locator('#geo-tab-settings').get_attribute('aria-selected')=='true'
 print('PASS switching sites clears prior questions; mobile layout and keyboard tab navigation work')
 state['empty']=True;page.reload();page.wait_for_function("document.querySelector('#geo-next-title').textContent.includes('أضف موقعك')")
 assert page.locator('#geo-next-actions a').get_attribute('href')=='/websites'
 assert page.locator('#geo-content').is_hidden()
 assert not errors, errors
 print('PASS empty account shows website onboarding without data errors; no browser exceptions')
 state['empty']=False;state['current']=True;state['set']={'version':4,'questions':[],'approved_at':None}
 page.reload();page.wait_for_selector('#geo-content',state='visible');page.locator('#geo-tab-questions').click()
 assert page.locator('#geo-question-set').count()==1
 page.locator('#geo-generate').click();page.wait_for_function("document.querySelector('#geo-question-set').value.includes('tour option')")
 assert not page.locator('#geo-set-approve').is_checked()
 page.locator('#geo-set-approve').check();page.locator('#geo-question-set').fill(page.locator('#geo-question-set').input_value().replace('option 0','option zero'))
 assert not page.locator('#geo-set-approve').is_checked()
 page.locator('#geo-set-approve').check();page.locator('#geo-questions button').click();page.wait_for_function("document.querySelector('#geo-reload').disabled===false")
 assert state['set']['version']==5 and state['set']['approved_at']
 assert state['posts'][-1][1]['version']==4 and len(state['posts'][-1][1]['questions'])==10
 page.locator('#geo-tab-settings').click();page.locator('#geo-entity-confirm').check();page.locator('#geo-identity button').click();page.wait_for_function("document.querySelector('#geo-reload').disabled===false")
 assert state['posts'][-1][1]['version']==2 and state['posts'][-1][1]['confirmed'] is True
 assert state['posts'][-1][1]['address']=='Confirmed address'
 print('PASS current service uses whole-list versioned approval, editing clears consent, and identity address/version are preserved')
 english=subprocess.check_output(['php','-r',"function current_lang(){return 'en';} class Csrf {static function token(){return 'fixture-csrf';}} require $argv[1];",str(view)],text=True)
 html='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><script>window.Panel={fetchJSON:async(u,o)=>{const r=await fetch(u,o);return r.json();}};</script><style>'+panel_css+'</style>'+english+'</html>'
 page.reload();page.wait_for_selector('#geo-content',state='visible')
 assert page.locator('#geo-root').get_attribute('dir')=='ltr'
 assert page.locator('#geo-tab-questions').inner_text()=='Questions'
 page.locator('#geo-tab-questions').click();assert 'complete list' in page.locator('#geo-questions').inner_text()
 assert not errors, errors
 print('PASS English page uses LTR and translated list-approval controls')
 browser.close()

````

## tests/Fixtures/Seo/controller_contract_probe.php

````php
<?php
/** Isolated offline probe: no application bootstrap, credentials, network or SQL. */
class Controller {
    public $db=null;public array $input=[];
    protected function get(string $key,$default=null){return $this->input[$key]??$default;}
}
class SeoMarketService {public function __construct($db){} public function markets($wid,$uid):array{return [['id'=>5,'label'=>'Egypt – Arabic']];}}
require dirname(__DIR__,3).'/app/Services/AiVisibility/AiVisibilityPresentation.php';
require dirname(__DIR__,3).'/app/Controllers/AiVisibilityController.php';
class CurrentServiceProbe {
    public array $calls=[];
    public function generate($uid,$wid,$mid):array{$this->calls[]=['generate',$uid,$wid,$mid];return ['questions'=>['Draft question'],'market'=>['id'=>5]];}
    public function set($uid,$wid,$mid):array{return ['version'=>4];}
    public function save($uid,$wid,$mid,$questions,$version,$approved):void{$this->calls[]=['save',$uid,$wid,$mid,$questions,$version,$approved];if($version!==4)throw new InvalidArgumentException('version_conflict');}
    public function entities($uid,$wid,$aliases,$profiles,$address,$version,$confirmed):void{$this->calls[]=['entities',$uid,$wid,$aliases,$profiles,$address,$version,$confirmed];}
    public function overview($uid,$wid,$mid):array{$this->calls[]=['overview',$uid,$wid,$mid];return ['state'=>'not_measured','market'=>['id'=>5],'metrics'=>['state'=>'not_measured','providers'=>[]],'prompt_set'=>null,'providers'=>[]];}
}
$c=new AiVisibilityController();$s=new CurrentServiceProbe();$method=new ReflectionMethod($c,'currentContract');$method->setAccessible(true);$checks=0;
function check($value){global $checks;if(!$value)throw new RuntimeException('Contract probe failed at check '.($checks+1));$checks++;}
$r=$method->invoke($c,$s,'generate',7,32,5);check($r['set_version']===4&&$r['draft_questions']===['Draft question']);check(count($s->calls)===1); // draft generation never saves or approves
$c->input=['questions'=>['Reviewed question'],'version'=>4,'approved'=>true];$r=$method->invoke($c,$s,'question',7,32,5);check($r['saved']===true&&end($s->calls)===['save',7,32,5,['Reviewed question'],4,true]);
$c->input=['questions'=>['Changed question'],'version'=>3,'approved'=>true];try{$method->invoke($c,$s,'question',7,32,5);check(false);}catch(InvalidArgumentException $e){check($e->getMessage()==='version_conflict');}
$c->input=['id'=>0,'question'=>'One question','approved'=>true];try{$method->invoke($c,$s,'question',7,32,5);check(false);}catch(InvalidArgumentException $e){check(true);}
$c->input=['version'=>2,'confirmed'=>true,'aliases'=>['Example'],'profile_urls'=>['https://example.com'],'address'=>'Confirmed address'];$r=$method->invoke($c,$s,'identity',7,32,5);check(end($s->calls)===['entities',7,32,['Example'],['https://example.com'],'Confirmed address',2,true]);
$c->input=['version'=>2,'confirmed'=>false];try{$method->invoke($c,$s,'identity',7,32,5);check(false);}catch(InvalidArgumentException $e){check(true);}
$r=$method->invoke($c,$s,'overview',7,32,5);check(end($s->calls)===['overview',7,32,5]&&$r['markets'][0]['id']===5&&$r['question_mode']==='set');
echo json_encode(['passed'=>$checks]);

````

## tests/Unit/SeoPackageCompatibilityTest.php

````php
<?php
use PHPUnit\Framework\TestCase;
require_once __DIR__.'/../../app/Services/AiVisibility/AiVisibilityPresentation.php';
final class SeoPackageCompatibilityTest extends TestCase
{
    private function current(): array
    {
        return ['state'=>'measured_sample','market'=>['id'=>5],'markets'=>[['id'=>5,'label'=>'Egypt – Arabic']],
            'providers'=>['openai'=>['configured'=>true,'model'=>'PRIVATE_MODEL']],
            'metrics'=>['state'=>'measured_sample','providers'=>['openai'=>['state'=>'measured_sample','week_start'=>'2026-10-12','stale'=>true,'partial'=>true,'questions'=>2,'share_of_voice'=>.5,'citation_rate'=>null,'citation_questions'=>0,'top_competitors'=>['Observed competitor'=>1],'trend'=>[['week'=>'2026-10-05','questions'=>0,'share_of_voice'=>null,'citation_rate'=>null],['week'=>'2026-10-12','questions'=>2,'share_of_voice'=>.5,'citation_rate'=>null]]]]],
            'prompt_set'=>['version'=>4,'approved_at'=>'2026-10-12 12:00:00','questions'=>['A reviewed traveler question?'],'facts_hash'=>'PRIVATE_HASH'],
            'entities'=>['version'=>2,'aliases'=>['Example Tours'],'profiles'=>['https://example.com'],'address'=>'Confirmed address','user_id'=>7],
            'profile_state'=>'confirmed','answers'=>[['provider'=>'openai','question'=>'A reviewed traveler question?','model'=>'PRIVATE_MODEL','cost'=>10,'answer_excerpt'=>'Observed answer']], 'tasks'=>[]];
    }
    public function testNestedMetricsKeepSampleDateAndNullCitationWithoutFakeZero(): void
    {
        $r=AiVisibilityPresentation::customer($this->current());
        $this->assertSame(.5,$r['metrics'][0]['share_of_voice']);$this->assertNull($r['metrics'][0]['citation_rate']);
        $this->assertSame(5,$r['metrics'][0]['market_id']);$this->assertTrue($r['metrics'][0]['stale']);$this->assertTrue($r['metrics'][0]['partial']);
        $this->assertSame('2026-10-12',$r['metrics'][0]['week_start']);$this->assertCount(1,$r['trend']);$this->assertSame(2,$r['trend'][0]['providers'][0]['questions']);
    }
    public function testVersionedApprovalAndIdentityRemainUsableWithoutPrivateFields(): void
    {
        $r=AiVisibilityPresentation::customer($this->current());
        $this->assertSame('set',$r['question_mode']);$this->assertSame(4,$r['question_set']['version']);$this->assertSame(1,$r['questions'][0]['approved']);
        $this->assertSame(5,$r['answers'][0]['market_id']);$this->assertSame(2,$r['entity_version']);$this->assertSame(['Example Tours'],$r['identity_aliases']);
        $json=json_encode($r);$this->assertStringNotContainsString('PRIVATE_',$json);$this->assertStringNotContainsString('configured',$json);$this->assertArrayNotHasKey('cost',$r['answers'][0]);
    }
    public function testNoSamplesStayUnmeasured(): void
    {
        $data=$this->current();$data['metrics']['providers']['openai']['questions']=0;$data['metrics']['providers']['openai']['trend']=[];$data['answers']=[];
        $r=AiVisibilityPresentation::customer($data);$this->assertSame('not_measured',$r['state']);$this->assertSame([],$r['metrics']);
    }
    public function testControllerForwardsMarketVersionConsentAndRejectsConflicts(): void
    {
        $command=escapeshellarg(PHP_BINARY).' -n '.escapeshellarg(__DIR__.'/../Fixtures/Seo/controller_contract_probe.php');
        exec($command,$output,$status);$this->assertSame(0,$status,implode("\n",$output));$this->assertJson(implode("\n",$output),implode("\n",$output));$this->assertSame(8,json_decode(implode("\n",$output),true)['passed']);
    }
    public function testBothTranslationDictionariesHaveIdenticalKeys(): void
    {
        $ar=require __DIR__.'/../../app/Lang/ai_visibility_ar.php';$en=require __DIR__.'/../../app/Lang/ai_visibility_en.php';
        $this->assertSame(array_keys($ar),array_keys($en));$this->assertNotSame($ar,$en);$this->assertGreaterThan(100,count($en));
    }
}

````

