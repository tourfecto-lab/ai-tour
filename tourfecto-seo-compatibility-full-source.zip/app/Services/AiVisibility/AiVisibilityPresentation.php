<?php
/** Customer API projection: internal configuration and provider spending never leave the server. */
final class AiVisibilityPresentation
{
    private const LABELS=['openai'=>'ChatGPT','gemini'=>'Gemini','perplexity'=>'Perplexity'];
    private static function objectArray($value): array
    {
        if(is_string($value))$value=json_decode($value,true);
        return is_array($value)?$value:[];
    }
    private static function rows($value): array
    {
        $rows=[];
        foreach(self::objectArray($value) as $row){
            $row=self::objectArray($row);
            if($row!==[])$rows[]=$row;
        }
        return $rows;
    }
    private static function normalizeCurrent(array $data): array
    {
        if(!isset($data['market'])||!is_array($data['market'])||!array_key_exists('prompt_set',$data))return $data;
        $mid=(int)$data['market']['id'];$metrics=self::objectArray($data['metrics']??[]);$flat=[];$weeks=[];
        foreach(self::objectArray($metrics['providers']??[]) as $provider=>$value){
            if(!isset(self::LABELS[$provider])||!is_array($value))continue;
            if((int)($value['questions']??0)>0)$flat[]=array_intersect_key($value,array_flip(['questions','share_of_voice','citation_rate','citation_questions','week_start','stale','partial']))+['provider'=>$provider,'market_id'=>$mid,'competitors'=>self::objectArray($value['top_competitors']??[])];
            foreach(self::rows($value['trend']??[]) as $point){
                if((int)($point['questions']??0)===0||!isset($point['week']))continue;
                $week=(string)$point['week'];$weeks[$week]['week']=$week;
                $weeks[$week]['providers'][]=array_intersect_key($point,array_flip(['questions','share_of_voice','citation_rate']))+['provider'=>$provider,'market_id'=>$mid];
            }
        }
        ksort($weeks);$data['metrics']=$flat;$data['trend']=array_values($weeks);
        $data['state']=$flat?'measured':'not_measured';
        $set=self::objectArray($data['prompt_set']);
        $data['question_mode']='set';$data['question_set']=['version'=>(int)($set['version']??0),'approved_at'=>$set['approved_at']??null,'questions'=>array_values(array_filter(self::objectArray($set['questions']??[]),'is_string'))];
        $data['questions']=[];foreach($data['question_set']['questions'] as $i=>$question)$data['questions'][]=['id'=>$i,'market_id'=>$mid,'question'=>$question,'approved'=>empty($set['approved_at'])?0:1];
        $entity=self::objectArray($data['entities']??[]);
        $data['identity_aliases']=array_values(array_filter(self::objectArray($entity['aliases']??[]),'is_string'));
        $data['entity_version']=(int)($entity['version']??0);$data['entity_address']=(string)($entity['address']??'');
        $data['aliases']=$data['identity_aliases'];$data['profile_urls']=array_values(array_filter(self::objectArray($entity['profiles']??[]),'is_string'));
        $data['profile_state']=$data['profile_state']??'needs_confirmed_business_profile';
        $data['answers']=array_map(static fn($row)=>$row+['market_id'=>$mid],self::rows($data['answers']??[]));
        return $data;
    }
    public static function customer(array $data): array
    {
        $data=self::normalizeCurrent($data);
        foreach(['metrics','trend','answers','questions','tasks','markets'] as $key)$data[$key]=self::rows($data[$key]??[]);
        $data['providers']=self::objectArray($data['providers']??[]);
        $out=array_intersect_key($data,array_flip(['state','markets','questions','metrics','trend','aliases','profile_urls','position_basis','question_mode','question_set','identity_aliases','entity_version','entity_address','profile_state']));
        $projectMetric=static fn($m)=>array_intersect_key($m,array_flip(['provider','market_id','questions','mentions','citations','citation_questions','share_of_voice','citation_rate','competitors','week_start','stale','partial']));
        $out['metrics']=array_map($projectMetric,$data['metrics']??[]);
        $out['trend']=array_map(static fn($w)=>['week'=>$w['week']??'','providers'=>array_map($projectMetric,self::rows($w['providers']??[]))],$data['trend']??[]);
        $out['setup']='أكد بيانات شركتك، واختار السوق، وبعدها راجع أسئلة عملائك ووافق على الأسئلة اللي تحب تتابع ظهور شركتك فيها. النتائج هتظهر بعد أول قياس.';
        $out['providers']=[];foreach(array_unique(array_merge(array_keys($data['providers']??[]),array_column($data['metrics']??[],'provider'))) as $provider)if(isset(self::LABELS[$provider]))$out['providers'][$provider]=['label'=>self::LABELS[$provider]];
        $out['answers']=array_map(static fn($row)=>array_intersect_key($row,array_flip(['provider','market_id','question','mentioned_brand','cited_domain','brand_position','cited_urls','competitors_mentioned','answer_excerpt','checked_at'])), $data['answers']??[]);
        $out['questions']=array_map(static fn($row)=>array_intersect_key($row,array_flip(['id','market_id','question','approved'])), $data['questions']??[]);
        $out['tasks']=array_map(static function($row){$safe=array_intersect_key($row,array_flip(['title','instructions','status']));$e=self::objectArray($row['evidence_json']??[]);$safe['evidence_json']=json_encode(array_intersect_key($e,array_flip(['url','customer_url','kind','checked_at','observed_differences'])),JSON_UNESCAPED_UNICODE);return $safe;},$data['tasks']??[]);
        return $out;
    }
}
