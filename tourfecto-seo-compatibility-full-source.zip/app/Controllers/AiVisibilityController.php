<?php
final class AiVisibilityController extends Controller
{
    public function data(array $params=[]): array
    {
        if(!$this->isAuthenticated())return $this->error('Unauthorized',401);
        if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'&&($err=$this->verifyCsrf()))return $err;
        try{$uid=(int)$this->user['id'];$wid=(int)$this->get('website_id');$svc=new AiVisibilityService($this->db);$action=$params['action']??'overview';
            if(method_exists($svc,'save')&&method_exists($svc,'entities'))return $this->success($this->currentContract($svc,$action,$uid,$wid,(int)$this->get('market_id')));
            $result=match($action){
                'generate'=>$svc->generate($uid,$wid,(int)$this->get('market_id')),
                'question'=>$svc->saveQuestion($uid,$wid,(int)$this->get('id'),trim((string)$this->get('question')),$this->get('approved')===true),
                'identity'=>$svc->identity($uid,$wid,(array)$this->get('aliases',[]),(array)$this->get('profile_urls',[])),
                default=>$svc->overview($uid,$wid)
            };return $this->success(AiVisibilityPresentation::customer($result));
        }catch(InvalidArgumentException $e){return $this->error($e->getMessage(),422);}
        catch(Throwable $e){
            Logger::error('AI Visibility operation unavailable',[
                'action'=>$params['action']??'overview','website_id'=>(int)$this->get('website_id'),
                'user_id'=>(int)$this->user['id'],'exception'=>get_class($e),
                'error'=>$e->getMessage(),'file'=>$e->getFile(),'line'=>$e->getLine()
            ]);
            return $this->error('تعذر تحميل النتائج دلوقتي. جرّب مرة تانية أو تواصل مع الدعم.',503);
        }
    }
    /** Current package uses versioned, whole-list approval; do not emulate per-question consent. */
    private function currentContract(object $service,string $action,int $uid,int $wid,int $mid): array
    {
        if($action==='generate'){
            $draft=$service->generate($uid,$wid,$mid);
            $resolved=(int)$draft['market']['id'];
            $set=$service->set($uid,$wid,$resolved);
            return ['question_mode'=>'set','draft_questions'=>$draft['questions'],'set_version'=>(int)($set['version']??0),'market_id'=>$resolved];
        }
        if($action==='question'){
            $questions=$this->get('questions');if(is_string($questions))$questions=array_values(array_filter(array_map('trim',explode("\n",$questions)),static fn($q)=>$q!==''));$version=filter_var($this->get('version'),FILTER_VALIDATE_INT);
            if(!is_array($questions)||$version===false||$version<0)throw new InvalidArgumentException('Review and save the complete question list with its current version. / راجع واحفظ قائمة الأسئلة كاملة بإصدارها الحالي.');
            $service->save($uid,$wid,$mid,$questions,$version,$this->get('approved')===true);
            return ['saved'=>true];
        }
        if($action==='identity'){
            $version=filter_var($this->get('version'),FILTER_VALIDATE_INT);
            if($version===false||$version<0||$this->get('confirmed')!==true)throw new InvalidArgumentException('Confirm the current company identity before saving. / أكد بيانات الشركة الحالية قبل الحفظ.');
            $lines=static fn($value)=>is_string($value)?array_values(array_filter(array_map('trim',explode("\n",$value)),static fn($line)=>$line!=='')):(array)$value;
            $service->entities($uid,$wid,$lines($this->get('aliases',[])),$lines($this->get('profile_urls',$this->get('profiles',[]))),(string)$this->get('address',''),$version,true);
            return ['saved'=>true];
        }
        $result=$service->overview($uid,$wid,$mid);
        $markets=new SeoMarketService($this->db);
        $result['markets']=$markets->markets($wid,$uid);
        return AiVisibilityPresentation::customer($result);
    }
    public function save(array $params=[]): array {return $this->data(['action'=>'question']);}
    public function entities(array $params=[]): array {return $this->data(['action'=>'identity']);}
    public function generate(array $params=[]): array {return $this->data(['action'=>'generate']);}
    public function question(array $params=[]): array {return $this->data(['action'=>'question']);}
    public function identity(array $params=[]): array {return $this->data(['action'=>'identity']);}
    public function llms(array $params=[]): array
    {
        if(!$this->isAuthenticated())return $this->error('Unauthorized',401);
        try{$service=new AiVisibilityService($this->db);if(method_exists($service,'llmsDraft'))return $this->success($service->llmsDraft((int)$this->user['id'],(int)$this->get('website_id')));$site=(new SeoMarketService($this->db))->owned((int)$this->get('website_id'),(int)$this->user['id']);$ctx=(new SeoExpertPageContext())->fresh($site['main_url']);if(empty($ctx['ok']))throw new RuntimeException('page_unavailable');return $this->success(['draft'=>(new LlmsSiteSummary())->fromContext($ctx),'status'=>'draft_requires_review','note'=>'راجع البيانات؛ النشر من خلال دورة الموصل الحالية مع موافقة وتحقق وإمكانية رجوع. مفيش ضمان ترتيب.']);}catch(Throwable $e){return $this->error('تعذر قراءة الصفحات العامة',422);}
    }
    /** Compatibility with deployed web routes that still dispatch to index. */
    public function index(array $params=[]): array {return $this->page($params);}
    public function page(array $params=[]): array {if(!$this->isAuthenticated())return $this->error('Unauthorized',401);ob_start();require dirname(__DIR__).'/Views/AiVisibility/index.php';$body=ob_get_clean();
        $english=function_exists('current_lang')&&current_lang()!=='ar';
        echo $this->renderPanelPage('ai_analyze',$english?'Your AI visibility':'ظهورك في الذكاء الصناعي',$english?'Measured questions and sources':'قياسات فعلية للأسئلة والمصادر، بدون تقديرات',$body);return [];}
}
