"""Offline UI contract check. Requires PHP, Playwright Python and Chromium (development only)."""
import json, subprocess, os
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
view=root/'app/Views/AiVisibility/index.php'
html=subprocess.check_output(['php','-r',"class Csrf {static function token(){return 'fixture-csrf';}} require $argv[1];",str(view)],text=True)
panel_css=(root/'public_html/assets/css/panel.css').read_text()
html='<style>'+panel_css+'</style>'+html
html='<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><script>window.Panel={fetchJSON:async(u,o)=>{const r=await fetch(u,o);return r.json();}};</script>'+html+'</html>'
origin='https://ui.example.test'
state={'fail':False,'empty':False,'questions':[],'posts':[],'metrics':[]}
def payload(wid):
 if state.get('current'):
  return {'state':'not_measured','providers':{'openai':{'label':'ChatGPT'}},'markets':[{'id':wid*10,'label':'Egypt – English'}],'questions':[],'metrics':[],'answers':[],'trend':[],'tasks':[],'question_mode':'set','question_set':state['set'],'entity_version':2,'entity_address':'Confirmed address','identity_aliases':['Example'],'aliases':['Example'],'profile_urls':[]}
 return {'state':'not_measured','providers':{'openai':{'label':'ChatGPT'}},'markets':[{'id':wid*10,'label':'مصر — العربية'}], 'questions':state['questions'] if wid==1 else [],'metrics':state['metrics'],'answers':state.get('answers',[]), 'trend':[], 'tasks':[], 'aliases':['Example','Example Tours'],'profile_urls':['https://example.com']}
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.getenv('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 def handle(route):
  req=route.request;u=req.url
  if u==origin+'/':route.fulfill(status=200,content_type='text/html',body=html);return
  if '/api/websites' in u:route.fulfill(json={'success':True,'data':{'websites':[] if state['empty'] else [{'id':1,'main_url':'https://example.com'},{'id':2,'main_url':'https://second.example.com'}]}});return
  if '/api/ai-visibility/' in u:
   from urllib.parse import urlparse,parse_qs
   if req.method=='POST':
    body=req.post_data_json;state['posts'].append((u,body))
    if u.endswith('/generate') and state.get('current'):
     route.fulfill(json={'success':True,'data':{'draft_questions':['What can I compare for tour option '+str(i)+'?' for i in range(10)],'set_version':4,'market_id':10}});return
    if u.endswith('/question') and state.get('current'):
     assert body['version']==state['set']['version']
     state['set']={'version':5,'questions':body['questions'],'approved_at':'2026-10-17' if body['approved'] else None}
     route.fulfill(json={'success':True,'data':{'saved':True}});return
    if u.endswith('/generate'):state['questions']=[{'id':3,'market_id':10,'question':'ما الخدمات المتاحة؟','approved':0}]
    if u.endswith('/question'):state['questions']=[{'id':3,'market_id':10,'question':body['question'],'approved':int(body['approved'])}]
    route.fulfill(json={'success':True,'data':{}});return
   if state['fail']:route.fulfill(status=503,json={'success':False,'error':'تعذر تحميل البيانات، حاول تاني'});return
   wid=int(parse_qs(urlparse(u).query)['website_id'][0]);route.fulfill(json={'success':True,'data':payload(wid)});return
  route.abort()
 page.route('**/*',handle)
 page.goto(origin+'/');page.wait_for_selector('#geo-content',state='visible')
 assert 'جهّز أسئلة' in page.locator('#geo-next-title').inner_text(), page.locator('#geo-root').inner_text()
 assert page.locator('#geo-generate').is_hidden()
 page.locator('#geo-tab-questions').click();page.locator('#geo-generate').click();page.wait_for_selector('#geo-question-3')
 page.locator('#geo-question-3').fill('كيف أحجز رحلة مؤكدة؟');page.locator('.geo-question input[type=checkbox]').check();page.locator('.geo-question button').click()
 page.wait_for_function("document.querySelector('#geo-next-title').textContent.includes('جاهزة')")
 body=state['posts'][-1][1];assert body['approved'] is True and body['website_id']==1 and body['market_id']==10 and body['csrf_token']=='fixture-csrf'
 assert 'مش بيبدأ قياس جديد' in page.locator('#geo-state').inner_text()
 print('PASS generate, edit and approve question with market, site and CSRF; scheduled measurement explained')
 page.locator('#geo-tab-settings').click();page.locator('#geo-aliases').fill('Example Tours\nمثال');page.locator('#geo-identity button').click();page.wait_for_function("document.querySelector('#geo-reload').disabled===false")
 assert state['posts'][-1][1]['aliases']==['Example Tours','مثال']
 print('PASS identity form saves without triggering measurement')
 state['metrics']=[{'provider':'openai','market_id':10,'share_of_voice':.5,'citation_rate':None,'questions':2}]
 state['answers']=[{'provider':'openai','market_id':10,'question':'<img src=x onerror=alert(1)>','mentioned_brand':1,'cited_domain':None,'cited_urls':'["javascript:alert(1)","https://example.com/source"]','answer_excerpt':'<script>alert(1)</script>','checked_at':'2026-10-17'}]
 page.locator('#geo-reload').click();page.wait_for_function("document.querySelector('#geo-next-title').textContent.includes('متاحة')")
 page.locator('#geo-tab-results').click()
 assert '50.0%' in page.locator('#geo-cards').inner_text()
 assert page.locator('#geo-answers img, #geo-answers script').count()==0
 assert page.locator('#geo-answers a').count()==1
 assert page.locator('#geo-answers a').get_attribute('href')=='https://example.com/source'
 assert 'غير مقاس' in page.locator('#geo-cards').inner_text()
 assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
 screenshot=os.getenv('GEO_SCREENSHOT_PATH')
 if screenshot:page.screenshot(path=screenshot,full_page=True)
 print('PASS real metrics remain visible, unmeasured citations stay distinct, source links reject script URLs and text is escaped')
 state['fail']=True;page.locator('#geo-reload').click();page.wait_for_selector('#geo-message[data-error=true]')
 assert page.locator('#geo-content').is_hidden() and page.locator('#geo-site').input_value()=='1'
 assert page.locator('#geo-generate').is_disabled()
 state['fail']=False;page.locator('#geo-next-actions button').click();page.wait_for_selector('#geo-content',state='visible')
 print('PASS API error preserves site, hides stale content and supports retry')
 page.locator('#geo-site').select_option('2');page.wait_for_function("document.querySelector('#geo-market').value==='20' && document.querySelector('#geo-reload').disabled===false")
 page.locator('#geo-tab-questions').click();assert page.locator('.geo-question').count()==0
 assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'Mobile horizontal overflow'
 page.locator('#geo-tab-questions').focus();page.keyboard.press('ArrowLeft');assert page.locator('#geo-tab-settings').get_attribute('aria-selected')=='true'
 print('PASS switching sites clears prior questions; mobile layout and keyboard tab navigation work')
 state['empty']=True;page.reload();page.wait_for_function("document.querySelector('#geo-next-title').textContent.includes('أضف موقعك')")
 assert page.locator('#geo-next-actions a').get_attribute('href')=='/websites'
 assert page.locator('#geo-content').is_hidden()
 assert not errors, errors
 print('PASS empty account shows website onboarding without data errors; no browser exceptions')
 state['empty']=False;state['current']=True;state['set']={'version':4,'questions':[],'approved_at':None}
 page.reload();page.wait_for_selector('#geo-content',state='visible');page.locator('#geo-tab-questions').click()
 assert page.locator('#geo-question-set').count()==1
 page.locator('#geo-generate').click();page.wait_for_function("document.querySelector('#geo-question-set').value.includes('tour option')")
 assert not page.locator('#geo-set-approve').is_checked()
 page.locator('#geo-set-approve').check();page.locator('#geo-question-set').fill(page.locator('#geo-question-set').input_value().replace('option 0','option zero'))
 assert not page.locator('#geo-set-approve').is_checked()
 page.locator('#geo-set-approve').check();page.locator('#geo-questions button').click();page.wait_for_function("document.querySelector('#geo-reload').disabled===false")
 assert state['set']['version']==5 and state['set']['approved_at']
 assert state['posts'][-1][1]['version']==4 and len(state['posts'][-1][1]['questions'])==10
 page.locator('#geo-tab-settings').click();page.locator('#geo-entity-confirm').check();page.locator('#geo-identity button').click();page.wait_for_function("document.querySelector('#geo-reload').disabled===false")
 assert state['posts'][-1][1]['version']==2 and state['posts'][-1][1]['confirmed'] is True
 assert state['posts'][-1][1]['address']=='Confirmed address'
 print('PASS current service uses whole-list versioned approval, editing clears consent, and identity address/version are preserved')
 english=subprocess.check_output(['php','-r',"function current_lang(){return 'en';} class Csrf {static function token(){return 'fixture-csrf';}} require $argv[1];",str(view)],text=True)
 html='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><script>window.Panel={fetchJSON:async(u,o)=>{const r=await fetch(u,o);return r.json();}};</script><style>'+panel_css+'</style>'+english+'</html>'
 page.reload();page.wait_for_selector('#geo-content',state='visible')
 assert page.locator('#geo-root').get_attribute('dir')=='ltr'
 assert page.locator('#geo-tab-questions').inner_text()=='Questions'
 page.locator('#geo-tab-questions').click();assert 'complete list' in page.locator('#geo-questions').inner_text()
 assert not errors, errors
 print('PASS English page uses LTR and translated list-approval controls')
 browser.close()
