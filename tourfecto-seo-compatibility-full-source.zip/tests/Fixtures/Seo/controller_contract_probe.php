<?php
/** Isolated offline probe: no application bootstrap, credentials, network or SQL. */
class Controller {
    public $db=null;public array $input=[];
    protected function get(string $key,$default=null){return $this->input[$key]??$default;}
}
class SeoMarketService {public function __construct($db){} public function markets($wid,$uid):array{return [['id'=>5,'label'=>'Egypt – Arabic']];}}
require dirname(__DIR__,3).'/app/Services/AiVisibility/AiVisibilityPresentation.php';
require dirname(__DIR__,3).'/app/Controllers/AiVisibilityController.php';
class CurrentServiceProbe {
    public array $calls=[];
    public function generate($uid,$wid,$mid):array{$this->calls[]=['generate',$uid,$wid,$mid];return ['questions'=>['Draft question'],'market'=>['id'=>5]];}
    public function set($uid,$wid,$mid):array{return ['version'=>4];}
    public function save($uid,$wid,$mid,$questions,$version,$approved):void{$this->calls[]=['save',$uid,$wid,$mid,$questions,$version,$approved];if($version!==4)throw new InvalidArgumentException('version_conflict');}
    public function entities($uid,$wid,$aliases,$profiles,$address,$version,$confirmed):void{$this->calls[]=['entities',$uid,$wid,$aliases,$profiles,$address,$version,$confirmed];}
    public function overview($uid,$wid,$mid):array{$this->calls[]=['overview',$uid,$wid,$mid];return ['state'=>'not_measured','market'=>['id'=>5],'metrics'=>['state'=>'not_measured','providers'=>[]],'prompt_set'=>null,'providers'=>[]];}
}
$c=new AiVisibilityController();$s=new CurrentServiceProbe();$method=new ReflectionMethod($c,'currentContract');$method->setAccessible(true);$checks=0;
function check($value){global $checks;if(!$value)throw new RuntimeException('Contract probe failed at check '.($checks+1));$checks++;}
$r=$method->invoke($c,$s,'generate',7,32,5);check($r['set_version']===4&&$r['draft_questions']===['Draft question']);check(count($s->calls)===1); // draft generation never saves or approves
$c->input=['questions'=>['Reviewed question'],'version'=>4,'approved'=>true];$r=$method->invoke($c,$s,'question',7,32,5);check($r['saved']===true&&end($s->calls)===['save',7,32,5,['Reviewed question'],4,true]);
$c->input=['questions'=>['Changed question'],'version'=>3,'approved'=>true];try{$method->invoke($c,$s,'question',7,32,5);check(false);}catch(InvalidArgumentException $e){check($e->getMessage()==='version_conflict');}
$c->input=['id'=>0,'question'=>'One question','approved'=>true];try{$method->invoke($c,$s,'question',7,32,5);check(false);}catch(InvalidArgumentException $e){check(true);}
$c->input=['version'=>2,'confirmed'=>true,'aliases'=>['Example'],'profile_urls'=>['https://example.com'],'address'=>'Confirmed address'];$r=$method->invoke($c,$s,'identity',7,32,5);check(end($s->calls)===['entities',7,32,['Example'],['https://example.com'],'Confirmed address',2,true]);
$c->input=['version'=>2,'confirmed'=>false];try{$method->invoke($c,$s,'identity',7,32,5);check(false);}catch(InvalidArgumentException $e){check(true);}
$r=$method->invoke($c,$s,'overview',7,32,5);check(end($s->calls)===['overview',7,32,5]&&$r['markets'][0]['id']===5&&$r['question_mode']==='set');
echo json_encode(['passed'=>$checks]);
