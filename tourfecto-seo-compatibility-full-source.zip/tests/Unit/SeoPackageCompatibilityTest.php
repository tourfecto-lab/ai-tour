<?php
use PHPUnit\Framework\TestCase;
require_once __DIR__.'/../../app/Services/AiVisibility/AiVisibilityPresentation.php';
final class SeoPackageCompatibilityTest extends TestCase
{
    private function current(): array
    {
        return ['state'=>'measured_sample','market'=>['id'=>5],'markets'=>[['id'=>5,'label'=>'Egypt – Arabic']],
            'providers'=>['openai'=>['configured'=>true,'model'=>'PRIVATE_MODEL']],
            'metrics'=>['state'=>'measured_sample','providers'=>['openai'=>['state'=>'measured_sample','week_start'=>'2026-10-12','stale'=>true,'partial'=>true,'questions'=>2,'share_of_voice'=>.5,'citation_rate'=>null,'citation_questions'=>0,'top_competitors'=>['Observed competitor'=>1],'trend'=>[['week'=>'2026-10-05','questions'=>0,'share_of_voice'=>null,'citation_rate'=>null],['week'=>'2026-10-12','questions'=>2,'share_of_voice'=>.5,'citation_rate'=>null]]]]],
            'prompt_set'=>['version'=>4,'approved_at'=>'2026-10-12 12:00:00','questions'=>['A reviewed traveler question?'],'facts_hash'=>'PRIVATE_HASH'],
            'entities'=>['version'=>2,'aliases'=>['Example Tours'],'profiles'=>['https://example.com'],'address'=>'Confirmed address','user_id'=>7],
            'profile_state'=>'confirmed','answers'=>[['provider'=>'openai','question'=>'A reviewed traveler question?','model'=>'PRIVATE_MODEL','cost'=>10,'answer_excerpt'=>'Observed answer']], 'tasks'=>[]];
    }
    public function testNestedMetricsKeepSampleDateAndNullCitationWithoutFakeZero(): void
    {
        $r=AiVisibilityPresentation::customer($this->current());
        $this->assertSame(.5,$r['metrics'][0]['share_of_voice']);$this->assertNull($r['metrics'][0]['citation_rate']);
        $this->assertSame(5,$r['metrics'][0]['market_id']);$this->assertTrue($r['metrics'][0]['stale']);$this->assertTrue($r['metrics'][0]['partial']);
        $this->assertSame('2026-10-12',$r['metrics'][0]['week_start']);$this->assertCount(1,$r['trend']);$this->assertSame(2,$r['trend'][0]['providers'][0]['questions']);
    }
    public function testVersionedApprovalAndIdentityRemainUsableWithoutPrivateFields(): void
    {
        $r=AiVisibilityPresentation::customer($this->current());
        $this->assertSame('set',$r['question_mode']);$this->assertSame(4,$r['question_set']['version']);$this->assertSame(1,$r['questions'][0]['approved']);
        $this->assertSame(5,$r['answers'][0]['market_id']);$this->assertSame(2,$r['entity_version']);$this->assertSame(['Example Tours'],$r['identity_aliases']);
        $json=json_encode($r);$this->assertStringNotContainsString('PRIVATE_',$json);$this->assertStringNotContainsString('configured',$json);$this->assertArrayNotHasKey('cost',$r['answers'][0]);
    }
    public function testNoSamplesStayUnmeasured(): void
    {
        $data=$this->current();$data['metrics']['providers']['openai']['questions']=0;$data['metrics']['providers']['openai']['trend']=[];$data['answers']=[];
        $r=AiVisibilityPresentation::customer($data);$this->assertSame('not_measured',$r['state']);$this->assertSame([],$r['metrics']);
    }
    public function testControllerForwardsMarketVersionConsentAndRejectsConflicts(): void
    {
        $command=escapeshellarg(PHP_BINARY).' -n '.escapeshellarg(__DIR__.'/../Fixtures/Seo/controller_contract_probe.php');
        exec($command,$output,$status);$this->assertSame(0,$status,implode("\n",$output));$this->assertJson(implode("\n",$output),implode("\n",$output));$this->assertSame(8,json_decode(implode("\n",$output),true)['passed']);
    }
    public function testBothTranslationDictionariesHaveIdenticalKeys(): void
    {
        $ar=require __DIR__.'/../../app/Lang/ai_visibility_ar.php';$en=require __DIR__.'/../../app/Lang/ai_visibility_en.php';
        $this->assertSame(array_keys($ar),array_keys($en));$this->assertNotSame($ar,$en);$this->assertGreaterThan(100,count($en));
    }
}
