# Uploaded SEO package: compatibility review and correction

Date: 2026-10-17 (Africa/Cairo). Branch: `fix/seo-package-contract-compatibility`.

## Scope and assumption

The user supplied architecture and hard rules but no numbered feature prompt or acceptance list. After “متابعة”, the selected scope is to review the supplied package and correct proven AI visibility integration defects, retaining existing SEO execution and billing. This is not delivery or certification of the whole SEO roadmap. Risk tier definitions were not supplied, so no new automatic permission tier or live-site execution is introduced.

The ZIP was extracted separately and not copied over the checkout. Its PHP files passed syntax checks: 192/192. The snapshot has 46 files absent from the checkout, 57 differing files and 125 identical files (excluding directory entries). This divergence explains why mixing entire release maps or service implementations is inappropriate. Syntax checks are not functional validation.

## Design and exact file list

Production:
- CHANGE `app/Controllers/AiVisibilityController.php`: dispatch to the installed contract; preserve authenticated index/page and CSRF handling. Modern requests use whole-list `save`, `entities` and service-owned `llmsDraft`; legacy calls remain available. Pass selected market to modern overview and obtain owned markets through existing service. Draft generation never saves or approves questions. Add save/entities action aliases without replacing route files. Reject missing identity confirmation or question-list version. Delegate stale-version rejection and ownership enforcement to existing services.
- CHANGE `app/Services/AiVisibility/AiVisibilityPresentation.php`: normalize the current package response before applying customer allowlists. Retain actual rates, sample counts, dated samples, stale/partial flags and nullable citation values. Exclude empty trend observations rather than inventing zeroes. Keep set and identity versions for safe writes. Supply market identity on market-scoped answer rows. Continue excluding provider configuration, models, costs and internal evidence.
- CHANGE `app/Views/AiVisibility/index.php`: support whole-list review for current service and existing individual-question review for legacy service; draft generation remains unsaved. Editing a current list clears the approval checkbox; require explicit identity confirmation. Preserve saved address and identity version. Display dated/stale/partial samples. Retain guided tabs, mobile behavior, retry handling and safe source links. Load translations according to existing `current_lang()`; use English fallback for other supported UI languages.
- ADD `app/Lang/ai_visibility_ar.php`.
- ADD `app/Lang/ai_visibility_en.php`.

Verification and documentation:
- ADD `tests/Unit/SeoPackageCompatibilityTest.php`.
- ADD `tests/Fixtures/Seo/controller_contract_probe.php` (offline fixture only; never deploy as an endpoint).
- CHANGE `tests/Automation/ai_visibility_ui_browser_test.py`.
- ADD `docs/seo/package-compatibility-review.md` (this file).

No new production class is added. No release classmap replacement, route-file replacement, provider client replacement, database change, dependency change or cron configuration is included.

## Proven defects

1. In the uploaded package, the controller invoked `saveQuestion` and `identity`, whereas its service exposes `save` and `entities` with versioned approval. Its llms endpoint also referenced a different service path.
2. Modern metrics contain scalar metadata plus a `providers` object. The previous projection treated metrics as a list; filtering malformed rows alone prevented exceptions but could discard actual measurements and their structure.
3. Overview returns `market`, `prompt_set`, and `entities`; older UI requires markets and questions. Mixing those contracts produced empty selectors and unusable editing controls.
4. Whole-list approval cannot safely be represented by arbitrary per-question IDs. This patch shows the actual approval boundary instead of emulating unsupported individual consent.

## SQL migration

Not applicable: this correction adds no table, column or stored data format. There is intentionally no SQL file to run. Existing SEO/GEO migrations required by the deployed service must already be installed. This ZIP is not a substitute for an initial installation or missing phase migrations.

## Tests and exact commands

```sh
php -l app/Controllers/AiVisibilityController.php
php -l app/Services/AiVisibility/AiVisibilityPresentation.php
php -l app/Views/AiVisibility/index.php
php -l app/Lang/ai_visibility_ar.php
php -l app/Lang/ai_visibility_en.php
vendor/bin/phpunit --no-configuration --bootstrap tests/Unit/offline_bootstrap.php tests/Unit/SeoPackageCompatibilityTest.php
python3 tests/Automation/ai_visibility_ui_browser_test.py
php tests/Automation/ai_visibility_page_compatibility_test.php
php tests/Automation/ai_visibility_error_logging_test.php
php tests/Automation/ai_visibility_projection_shapes_test.php
php tests/Automation/admin_connections_customer_test.php
```

Results: PHPUnit 5 tests / 25 assertions; browser 8 scenarios; existing regression scripts 5/5, 3/3, 17/17 and 26/26. Browser fixtures simulate both payload contracts and responses; they make no paid provider calls. PHPUnit controller probe verifies delegation, drafts not saved implicitly, required confirmation, explicit approval/version forwarding, and propagation of version conflict. It uses a fresh PHP process with `-n` because the fixture requires no PHP extensions or application configuration. This is not a database concurrency stress test.

## Deployment and rollback

1. Back up the five production paths listed above. Record which dictionary files did not previously exist.
2. Upload only the production ZIP over the current installation, preserving paths. Keep tests, full-code listing and documentation off the public web root.
3. Invalidate hosting OPcache if enabled, then reload `/ai-visibility`.
4. Test as a customer: select an owned website and market; generate a draft; verify it is not approved or saved automatically; review and save 10–30 questions with explicit list approval; edit again and verify approval is cleared; reload and confirm saved state; review identity and confirm before saving; review actual source/date/sample size when data exists.
5. Test a second browser session: load the same set in both sessions; save in the first; saving the stale second copy must be rejected by the service rather than replacing newer data.
6. Test Arabic and English, a customer with no website, API failure/retry, and a second website with different questions. Confirm no API keys, provider models, configuration or provider billing fields appear.
7. No new provider/admin setting or API key is required for this patch. Existing providers and scheduled jobs retain their configuration.

Rollback: restore the backed-up production files together and invalidate OPcache. Delete new dictionaries only after restoring the view that no longer references them. There is no database rollback. Lists and identities deliberately saved by customers through the existing services remain stored; rolling back PHP files does not undo those customer actions. This correction does not touch the live customer website or change SEO execution policy.

## Acceptance evidence for this correction

- [x] Modern whole-list and legacy individual-question contracts are distinguished.
- [x] Real rates, nullable citation results, sample counts and dates survive projection.
- [x] No unmeasured observation becomes an invented zero.
- [x] Customer payload excludes internal provider readiness, models, costs and setup instructions.
- [x] Current service receives selected market, user/site identity and optimistic version.
- [x] Draft generation does not imply approval or persistence.
- [x] Whole-list editing clears frontend approval; saving passes explicit consent.
- [x] Identity updates require confirmation, carry version and retain existing address.
- [x] Arabic/English dictionaries have matching keys; English uses LTR.
- [x] Offline tests, mobile UI, safe links and failure/retry checked locally.
- [x] No paid call, DDL, live-site mutation or new automation permission introduced.
- [ ] Live hosting, WordPress execution/rollback, real providers, shared-host worker timing and real GSC/GA4/billing integration are not verified by this correction.

## Other findings to address separately

The following are observed source-level issues, not fixed or certified here:
- `AiVisibilityService::run` has a 130-second work threshold and `AiVisibilityCheckJob` requests 240 seconds. `SeoExpertService` includes 65-second crawl and 150-second technical-check windows; `SeoWorkWindow` defaults to 65 seconds. These do not establish compliance with an approximately 60-second hosting ceiling. Correct treatment requires resumable boundaries and transport deadlines, not merely reducing a timer.
- The supplied snapshot excludes route registration, release map, most application configuration/i18n helpers and customer view files. Full deployed-route and application startup compatibility cannot be proved from this snapshot alone. The patch preserves existing route files.
- Several existing SQL statements rely on prior ownership checks and globally unique IDs rather than repeating both `user_id` and `website_id` in every statement. The strict query-scoping rule is not certified for the whole supplied codebase. This correction adds no SQL statements.
- The supplied `tests/Unit/phpunit.xml` references directories relative to its location that do not match the snapshot layout, and its normal bootstrap expects omitted application config. The targeted offline command above bypasses that configuration without disabling assertions.
- Existing live-change validation, reversibility, monthly caps, queue idempotency, prompt-injection controls, plugin signatures and measured business impact were not reimplemented or comprehensively audited in this limited fix.
