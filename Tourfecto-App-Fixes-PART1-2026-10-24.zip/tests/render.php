<?php
$root=(is_dir(dirname(__DIR__).'/working/app') ? dirname(__DIR__).'/working/app' : dirname(__DIR__).'/app');
class Controller {
 protected $user=['id'=>30];protected $db;
 protected function isAuthenticated(){return getenv('FIXTURE_AUTH')!=='0';}
 protected function error($m,$c=400,$d=[]):array{return ['success'=>false,'error'=>$m,'code'=>$c];}
 protected function tr($key){return $key;}
 protected function renderPanelPage($tab,$title,$subtitle,$body,$script=''):string{return '<!doctype html><html><head><meta charset="utf-8"></head><body>'.$body.'<script>'.$script.'</script></body></html>';}
}
function current_lang(){return 'en';}
$mode=$argv[1]??'crm';
if($mode==='reputation'){require $root.'/Controllers/ReputationController.php';(new ReflectionClass('ReputationController'))->newInstanceWithoutConstructor()->showReviews();exit;}
if($mode==='email'){
 require $root.'/Controllers/EmailMarketingController.php';$r=(new ReflectionClass('EmailMarketingController'))->newInstanceWithoutConstructor()->index();if(is_array($r))echo json_encode($r);echo 'AFTER_RENDER_SENTINEL';exit;
}
require $root.'/Controllers/CrmController.php';$r=(new ReflectionClass('CrmController'))->newInstanceWithoutConstructor()->showDeals();if(is_array($r))echo json_encode($r);echo 'AFTER_RENDER_SENTINEL';
