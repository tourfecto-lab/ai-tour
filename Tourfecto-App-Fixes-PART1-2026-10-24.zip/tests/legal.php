<?php
class Controller {}
function current_lang(){return 'ar';}
class PublicLayout {public static function render($d){return $d['body'];}}
require (is_dir(dirname(__DIR__).'/working/app') ? dirname(__DIR__).'/working/app' : dirname(__DIR__).'/app').'/Controllers/LegalController.php';
$r=new ReflectionClass('LegalController');$c=$r->newInstanceWithoutConstructor();$m=$r->getMethod('pageShell');
$english='<h1>Privacy Policy</h1><p>Stop marketing by replying STOP or إلغاء.</p>';$out=$m->invoke($c,'Privacy',$english);
foreach([str_contains($out,'lang="en"'),str_contains($out,'لا يمثل ترجمة'),str_contains($out,$english)] as $i=>$ok){if(!$ok)throw new RuntimeException('English document assertion '.$i);echo 'PASS English-policy check '.($i+1)."\n";}
$ar='<h1>سياسة الخصوصية</h1><p>هذا نص عربي كامل لسياسة الخصوصية وحقوق العملاء.</p>';$out=$m->invoke($c,'الخصوصية',$ar);
if(!str_contains($out,'lang="ar"')||str_contains($out,'لا يمثل ترجمة'))throw new RuntimeException('Arabic policy changed');
echo "PASS existing Arabic policy preserved\nRESULT: 4 legal-language checks passed, 0 failed.\n";
