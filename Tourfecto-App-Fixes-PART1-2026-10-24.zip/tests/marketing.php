<?php
class Controller {}
class MarketingContent {public static function t($v){return is_array($v)?$v[1]:$v;}public static function planName($k,$name){return $name;}}
class SubscriptionPlan {public static function allAsLegacyArray(){return ['seo'=>['name'=>'SEO','features'=>['review_credits'=>0]],'enterprise'=>['name'=>'Enterprise','features'=>['review_credits'=>100]]];}}
class PlatformServiceRegistry {public static function marketingMatrix($p){return ['reviews-reputation'=>['plans'=>['seo'=>['best'=>'included','worst'=>'included'],'enterprise'=>['best'=>'included','worst'=>'included']]],'ai-chat'=>['plans'=>[]]];}}
require (is_dir(dirname(__DIR__).'/working/app') ? dirname(__DIR__).'/working/app' : dirname(__DIR__).'/app').'/Controllers/MarketingController.php';
$r=new ReflectionClass('MarketingController');$c=$r->newInstanceWithoutConstructor();$m=$r->getMethod('planAvailability');$html=$m->invoke($c,'reviews-reputation');
foreach(['Included replies per month: 0','Tool access does not include a reply allowance.','Included replies per month: 100'] as $text){if(!str_contains(strip_tags($html),$text))throw new RuntimeException('Missing: '.$text);echo 'PASS '.$text."\n";}
if(str_contains($m->invoke($c,'ai-chat'),'reply allowance'))throw new RuntimeException('Unrelated feature changed');
echo "PASS unrelated feature availability preserved\nRESULT: 4 marketing checks passed, 0 failed.\n";
