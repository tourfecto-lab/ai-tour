<?php
error_reporting(E_ALL);
set_error_handler(static function($s,$m,$f,$l){throw new ErrorException($m,0,$s,$f,$l);});
class Controller {protected $user=['id'=>30];protected $db;protected function tr($key){return $key;}}
function current_lang(){return 'en';}
class Logger {public static function error($m,$v){throw new RuntimeException($m);}}
class OnboardingFixtureDB {
 public bool $external=true; public bool $builder=false;public array $calls=[];
 public function query($sql,$p){$this->calls[]=[$sql,$p];
  if(str_contains($sql,'SELECT slug FROM generated_websites'))return [];
  if(str_contains($sql,'COUNT(*) AS c FROM generated_websites'))return [['c'=>$this->builder?1:0]];
  if(str_contains($sql,'SELECT * FROM websites'))return $this->external?[['id'=>33,'is_verified'=>1]]:[];
  return [['c'=>0]];
 }
}
require (is_dir(dirname(__DIR__).'/working/app') ? dirname(__DIR__).'/working/app' : dirname(__DIR__).'/app').'/Controllers/DashboardController.php';
$ref=new ReflectionClass(DashboardController::class);$controller=$ref->newInstanceWithoutConstructor();$db=new OnboardingFixtureDB;$ref->getParentClass()->getProperty('db')->setValue($controller,$db);$m=$ref->getMethod('buildOnboardingScript');
$n=0;function check($b,$name){global $n;if(!$b)throw new RuntimeException($name);echo 'PASS '.++$n.' '.$name."\n";}
$html=$m->invoke($controller);
check(str_contains($html,'Review your existing website connection'),'existing external website recognized');
check(str_contains($html,'/seo-expert?page=results&amp;website_id=33'),'booking-measurement link scoped to existing website');
check(str_contains($html,'Platform booking availability — optional'),'native availability shown as optional');
check(str_contains($html,'Platform booking payments — optional'),'native payment setup shown as optional');
check(!str_contains($html,'اعمل موقع الحجز'),'external customer is not asked to create another booking site');
check(!array_filter($db->calls,static fn($q)=>$q[1]!==[30]),'every onboarding data query remains owner scoped');
$db->external=false;$html=$m->invoke($controller);
check(str_contains($html,'اعمل موقع الحجز'),'new customers retain builder onboarding');
$db->external=true;$db->builder=true;$html=$m->invoke($controller);
check(str_contains($html,'انشر موقع الحجز'),'customers using builder retain publication step');
echo "RESULT: $n onboarding checks passed, 0 failed.\n";
