<?php
error_reporting(E_ALL);
set_error_handler(static function($s,$m,$f,$l){throw new ErrorException($m,0,$s,$f,$l);});
$root=(is_dir(dirname(__DIR__).'/working/app') ? dirname(__DIR__).'/working/app' : dirname(__DIR__).'/app');
class Database {
    public static $instance;
    public array $queries=[];
    public array $stages=[];
    public bool $fail=false;
    public static function getInstance(){return self::$instance??=new self;}
    public function query($sql,$params=[]){
        $this->queries[]=[$sql,$params];
        if($this->fail)throw new RuntimeException('Fixture database unavailable');
        if(str_contains($sql,'crm_pipeline_stages'))return $this->stages;
        if(str_contains($sql,'AVG(rating)'))return [['total'=>3,'avg_rating'=>5,'replied'=>3,'avg_hours'=>12]];
        return [['cnt'=>3]];
    }
}
class InternationalSettingsService {public static function languages(){return ['en'=>'English','ar'=>'Arabic'];}}
require $root.'/Core/Model.php';
require $root.'/Models/CrmPipelineStage.php';
require $root.'/Models/AIArticle.php';
require $root.'/Services/AI/ArticleFaqContent.php';
require $root.'/Services/AI/ArticleGenerator.php';
require $root.'/Services/GoogleBusiness/GbpReputationAnalyticsService.php';
require $root.'/Services/SeoExpert/SeoKeywordConflictReview.php';
$n=0;function check($ok,$name){global $n;if(!$ok)throw new RuntimeException('FAIL: '.$name);echo 'PASS '.++$n.' '.$name."\n";}
$rows=[];for($i=0;$i<6;$i++)for($j=0;$j<6;$j++)$rows[]=['id'=>$i*6+$j+1,'agency_id'=>null,'pipeline_id'=>null,'slug'=>'stage'.$i,'name'=>'Stage '.$i,'sort_order'=>$i,'is_won'=>$i===4?1:0,'is_lost'=>$i===5?1:0];
$before=$rows;$groups=CrmPipelineStage::groupDefaultStages($rows);
check(count($groups)===6,'36 identical default stages produce six display groups');
check(count(array_merge(...array_column($groups,'stage_ids')))===36,'all legacy stage IDs retained');
check($rows===$before,'original rows unchanged');
check($groups[0]['stage_ids']===[1,2,3,4,5,6],'deals on duplicate IDs remain addressable');
$custom=$rows[0];$custom['pipeline_id']=99;$custom['id']=50;$different=$rows[0];$different['id']=51;$different['name']='Custom meaning';
check(count(CrmPipelineStage::groupDefaultStages([$rows[0],$rows[1],$custom,$different]))===3,'custom pipelines and different stage definitions preserved');
$db=Database::getInstance();$db->stages=$rows;
check(count((new CrmPipelineStage())->forPipeline(null))===6,'actual model query returns grouped default stages');
check(str_contains($db->queries[0][0],'`pipeline_id` IS NULL'),'default-stage query excludes named pipelines');
check(count((new CrmPipelineStage())->forPipeline(99))===36,'custom pipeline result is not collapsed');
$q='When should I visit?';$faq=[['question'=>$q,'answer'=>'October is an option.']];$body="Intro\n\n## FAQs\n$q\nA longer confirmed original answer.";
check(ArticleFaqContent::ensureVisible($body,$faq)===$body,'existing visible question does not gain second answer');
$legacy=$body."\n\n## $q\n\nOctober is an option.";
check(ArticleFaqContent::clean($legacy,$faq)===$body,'legacy appended duplicate removed, original answer preserved');
check(ArticleFaqContent::clean($legacy.' More discussion',$faq)===$legacy.' More discussion','nonmatching trailing content preserved');
$once=ArticleFaqContent::ensureVisible('Intro',$faq);
check(ArticleFaqContent::ensureVisible($once,$faq)===$once,'FAQ append idempotent');
check(ArticleFaqContent::ensureVisible('Intro',[])==='Intro','articles without FAQs preserved');
check(!ArticleFaqContent::hasQuestion('An introduction asking '.$q.' in a sentence',$q),'prose mention is not treated as an FAQ heading');
check(ArticleFaqContent::hasQuestion("## متى أزور؟",'متى أزور؟'),'Arabic question recognized');
$article=new AIArticle(['content'=>$legacy,'faqs_json'=>json_encode($faq)]);
check($article->contentForPresentation()===$body,'actual article model cleans preview/publish content');
check($article->getAttribute('content')===$legacy,'stored article body never modified by presentation');
$client=new class($body,$faq){public function __construct(private $body,private $faq){}public function generateContent($p,$o){return ['success'=>true,'data'=>json_encode(['title'=>'Travel','content'=>$this->body,'faqs'=>$this->faq])];}};
$generated=(new ArticleGenerator($client))->generate('Travel');
check($generated['success']&&$generated['data']['content']===$body,'actual generator preserves first FAQ without a second append');
check(count(json_decode($generated['data']['schema_suggestion'],true)['mainEntity'])===1,'FAQ schema retained separately');
$ref=new ReflectionClass(GbpReputationAnalyticsService::class);$svc=$ref->newInstanceWithoutConstructor();$ref->getProperty('db')->setValue($svc,$db);$m=$ref->getMethod('kpis');$stats=$m->invoke($svc,33,30,'2026-10-01');
check($stats['responded']===3&&$stats['response_rate']===100.0,'analytics count and reply-rate use the same replied total');
check($db->queries[count($db->queries)-3][1]===[33,30],'analytics query remains scoped to website and owner');
$db->fail=true;$stats=$m->invoke($svc,33,30,'2026-10-01');$db->fail=false;
check($stats['responded']===0,'empty/failure count has the same API shape');
$task=['field_name'=>'keyword_conflict','title'=>'Pages competing for: egypt tours','instructions'=>"Merge pages\nhttps://example.test/contact\nhttps://example.test/",'status'=>'needs_client'];
$snap=['keyword_map'=>['built_at'=>'2026-10-20','conflicts'=>[['query'=>'egypt tours','source'=>'same_target_keyword','pages'=>[['url'=>'https://example.test/contact']]]]]];
$present=SeoKeywordConflictReview::forTask($task,$snap,false);
check(str_contains($present['instructions'],'not ranking evidence'),'assigned keywords are not presented as ranking evidence');
check(!str_contains($present['instructions'],'Merge them into one page'),'unsafe generic merge recommendation replaced');
check($present['conflict_review']['automatic_merge']===false,'no automatic merge offered');
check($present['status']===$task['status'],'read-only presentation does not alter persisted task state');
check(SeoKeywordConflictReview::forTask(['field_name'=>'title'],$snap,false)===['field_name'=>'title'],'unrelated recommendations unchanged');
$measured=SeoKeywordConflictReview::instructions(['source'=>'search_console','pages'=>[['url'=>'https://example.test/a','clicks'=>0,'impressions'=>20,'position'=>7.1]]],false,'2026-10-20');
check(str_contains($measured,'Google Search Console')&&str_contains($measured,'clicks: 0')&&str_contains($measured,'2026-10-20'),'measured evidence includes source, zero clicks and timestamp');
echo "RESULT: $n passed, 0 failed; fake providers and database only.\n";
