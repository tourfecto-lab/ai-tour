<?php
require (is_dir(dirname(__DIR__).'/working/app') ? dirname(__DIR__).'/working/app' : dirname(__DIR__).'/app').'/Services/SocialMedia/SocialCalendarWindow.php';
$n=0;foreach([
 ['2026-10-24 10:00:00','2026-10-10 10:00:00','2026-12-01 00:00:00'],
 ['2026-01-01 00:00:00','2025-12-18 00:00:00','2026-03-01 00:00:00'],
 ['2028-01-31 12:00:00','2028-01-17 12:00:00','2028-03-01 00:00:00'],
 ['2026-12-31 23:59:59','2026-12-17 23:59:59','2027-02-01 00:00:00'],
] as [$now,$from,$until]){
 $r=SocialCalendarWindow::bounds(new DateTimeImmutable($now,new DateTimeZone('UTC')));
 if($r!==['from'=>$from,'until'=>$until])throw new RuntimeException(json_encode($r));echo 'PASS '.++$n.' full next-month coverage from '.$now."\n";
}
$tz=SocialCalendarWindow::bounds(new DateTimeImmutable('2026-11-01 01:00:00',new DateTimeZone('Africa/Cairo')));
if($tz['until']!=='2026-12-01 00:00:00')throw new RuntimeException('Timezone mismatch');
echo 'PASS '.++$n." timezone normalized to UTC\nRESULT: $n calendar checks passed, 0 failed.\n";
