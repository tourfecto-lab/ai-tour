<?php
final class SeoDataController extends Controller
{
    private function context(): array
    {
        if(!$this->isAuthenticated())throw new RuntimeException('Unauthorized');
        return [(int)$this->get('website_id'),(int)$this->user['id']];
    }
    public function markets(array $params=[]): array
    {
        try {[$wid,$uid]=$this->context();$svc=new SeoMarketService($this->db);return $this->success(['markets'=>$svc->list($wid,$uid),'limit'=>$svc->limit($uid)]);}catch(Throwable $e){return $this->error($e->getMessage(),422);}
    }
    public function addMarket(array $params=[]): array
    {
        if($err=$this->verifyCsrf())return $err;
        try {[$wid,$uid]=$this->context();return $this->success(['markets'=>(new SeoMarketService($this->db))->add($wid,$uid,['location_code'=>$this->get('location_code'),'language_code'=>$this->get('language_code'),'label'=>$this->get('label'),'is_primary'=>$this->get('is_primary')])]);}catch(Throwable $e){return $this->error($e->getMessage(),422);}
    }
    public function updateMarket(array $params=[]): array {if($err=$this->verifyCsrf())return $err;try{[$wid,$uid]=$this->context();return $this->success(['markets'=>(new SeoMarketService($this->db))->update($wid,$uid,(int)$this->get('market_id'),['location_code'=>$this->get('location_code'),'language_code'=>$this->get('language_code'),'label'=>$this->get('label'),'is_primary'=>$this->get('is_primary')])]);}catch(Throwable $e){return $this->error($e->getMessage(),422);}}
    public function adminMarkets(array $params=[]): array
    {
        if(!$this->isAuthenticated()||!AdminAccess::can($this->user,'users.edit'))return $this->error('Forbidden',403);
        if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'&&($err=$this->verifyCsrf()))return $err;
        try{$wid=(int)$this->get('website_id');$site=$this->db->query('SELECT user_id FROM websites WHERE id=?',[$wid]);if(!$site)throw new InvalidArgumentException('الموقع مش موجود');$uid=(int)$site[0]['user_id'];$s=new SeoMarketService($this->db);
            if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){$in=['location_code'=>$this->get('location_code'),'language_code'=>$this->get('language_code'),'label'=>$this->get('label'),'is_primary'=>$this->get('is_primary')];$mid=(int)$this->get('market_id');$mid?$s->update($wid,$uid,$mid,$in):$s->add($wid,$uid,$in);}
            return $this->success(['markets'=>$s->list($wid,$uid),'limit'=>$s->limit($uid)]);
        }catch(Throwable $e){return $this->error($e->getMessage(),422);}
    }
    public function adminPage(array $params=[]): array
    {
        if(!$this->isAuthenticated()||!AdminAccess::can($this->user,'users.edit'))return $this->error('Forbidden',403);
        $body='<div class="p-card"><h3>أسواق SEO للعملاء</h3><p>دخل رقم موقع العميل. market_id اختياري لتعديل سوق لسه مفيهوش قياسات.</p><form id="sm-admin"><input type="hidden" name="csrf_token" value="'.htmlspecialchars(Csrf::token(),ENT_QUOTES,'UTF-8').'"><input name="website_id" type="number" placeholder="رقم الموقع" required><input name="market_id" type="number" placeholder="رقم السوق للتعديل"><input name="label" placeholder="UK – English" required><input name="location_code" type="number" placeholder="2826" required><input name="language_code" placeholder="en" required><button>حفظ</button><button type="button" id="sm-list">عرض الأسواق</button></form><pre id="sm-result"></pre></div><script>document.addEventListener("DOMContentLoaded",()=>{const f=document.getElementById("sm-admin"),o=document.getElementById("sm-result");async function run(save){const d=Object.fromEntries(new FormData(f));const r=await window.Panel.fetchJSON("/api/admin/seo-markets"+(save?"":"?website_id="+encodeURIComponent(d.website_id)),save?{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(d)}:undefined);o.textContent=JSON.stringify(r,null,2)}f.onsubmit=e=>{e.preventDefault();run(true)};document.getElementById("sm-list").onclick=()=>run(false)});</script>';
        echo $this->renderPanelPage('admin','أسواق العملاء','استهداف البحث حسب الباقة',$body);return [];
    }
    public function overview(array $params=[]): array
    {
        try {[$wid,$uid]=$this->context();$markets=(new SeoMarketService($this->db))->list($wid,$uid);$mid=(int)$this->get('market_id',0);$market=(new SeoMarketService($this->db))->get($wid,$uid,$mid);$mid=(int)$market['id'];
            $rows=$this->db->query('SELECT r.*,CASE WHEN t.rank_source=\'dataforseo\' THEN t.current_position ELSE NULL END current_position,t.last_checked_at FROM seo_keyword_research r LEFT JOIN tracked_keywords t ON t.website_id=r.website_id AND t.market_id=r.market_id AND t.keyword=r.keyword WHERE r.website_id=? AND r.market_id=? ORDER BY r.volume DESC LIMIT 200',[$wid,$mid]);
            $tracked=$this->db->query('SELECT * FROM tracked_keywords WHERE website_id=? AND user_id=? AND market_id=? LIMIT 200',[$wid,$uid,$mid]);
            foreach($tracked as &$t){if(($t['rank_source']??'')!=='dataforseo')$t['current_position']=null;$t['history']=$this->db->query('SELECT position,checked_at FROM seo_rank_tracking_history WHERE website_id=? AND market_id=? AND keyword=? AND checked_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 30 DAY) ORDER BY checked_at',[$wid,$mid,$t['keyword']]);}unset($t);
            $configured=(new DataForSeoClient())->isConfigured();return $this->success(['available'=>$configured,'state'=>$configured?'configured':'not_measured','message'=>$configured?'البيانات المعروضة قياسات بتاريخها':'بيانات البحث مش متاحة دلوقتي. جرّب لاحقًا أو تواصل مع الدعم.','market'=>$market,'markets'=>$markets,'research'=>$rows,'tracked'=>$tracked,'gaps'=>(new DataForSeoResearchService($this->db))->gap($wid,$uid)]);
        }catch(Throwable $e){return $this->error($e->getMessage(),422);}
    }
    public function refreshCompetitors(array $params=[]): array {try{[$wid,$uid]=$this->context();(new DataForSeoResearchService($this->db))->competitors($wid,$uid);return $this->overview($params);}catch(Throwable $e){return $this->error($e->getMessage(),422);}}
    public function page(array $params=[]): array
    {
        if(!$this->isAuthenticated())return $this->error('Unauthorized',401);
        ob_start();require dirname(__DIR__).'/Views/SeoData/keywords.php';$body=ob_get_clean();
        echo $this->renderPanelPage('ai_analyze','الكلمات والأسواق','بيانات بحث وترتيب فعلية من DataForSEO',$body);return [];
    }
}
