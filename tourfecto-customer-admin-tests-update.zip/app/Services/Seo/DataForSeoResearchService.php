<?php
final class DataForSeoResearchService
{
    public function __construct(private Database $db,private ?DataForSeoClient $client=null){$this->client??=new DataForSeoClient();}
    public static function parse(array $items): array
    {
        $out=[];foreach($items as $item){$d=$item['keyword_data']??$item;$info=$d['keyword_info']??[];$properties=$d['keyword_properties']??[];$keyword=trim((string)($d['keyword']??''));if($keyword===''||mb_strlen($keyword)>255)continue;
            $number=static fn($v)=>is_numeric($v)&&is_finite((float)$v)&&(float)$v>=0?$v+0:null;
            $out[]=['keyword'=>$keyword,'volume'=>$number($info['search_volume']??null),'difficulty'=>$number($properties['keyword_difficulty']??$d['keyword_difficulty']??null),'cpc'=>$number($info['cpc']??null),'intent'=>$d['search_intent_info']['main_intent']??null,'position'=>isset($item['ranked_serp_element']['serp_item']['rank_group'])?(int)$item['ranked_serp_element']['serp_item']['rank_group']:null,'url'=>$item['ranked_serp_element']['serp_item']['url']??null];
        }return $out;
    }
    public function research(int $wid,int $uid,int $mid,array $seeds=[]): array
    {
        $markets=new SeoMarketService($this->db);$site=$markets->owned($wid,$uid);$market=$markets->get($wid,$uid,$mid);$mid=(int)$market['id'];
        if(!$this->client->isConfigured())return ['available'=>false,'state'=>'not_measured','message'=>'بيانات البحث مش متاحة دلوقتي. جرّب لاحقًا أو تواصل مع الدعم.','keywords'=>[]];
        $seeds=array_values(array_unique(array_filter(array_map('trim',$seeds))));if(count($seeds)>20)throw new InvalidArgumentException('حد البحث 20 كلمة');foreach($seeds as $s)if(mb_strlen($s)>255)throw new InvalidArgumentException('الكلمة طويلة');
        $hash=hash('sha256',json_encode([$seeds,$site['main_url']]));
        $cache=$this->db->query('SELECT 1 FROM seo_research_cache WHERE website_id=? AND market_id=? AND request_hash=? AND fetched_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 30 DAY)',[$wid,$mid,$hash]);
        if(!$cache){
            $task=['location_code'=>(int)$market['location_code'],'language_code'=>$market['language_code'],'limit'=>50];
            if($seeds){$task['keywords']=$seeds;$endpoint='keyword_ideas';}else{$task['target']=DataForSeoRankingSource::host($site['main_url']);$endpoint='keywords_for_site';}
            $data=self::parse(DataForSeoClient::items($this->client->call('dataforseo_labs/google/'.$endpoint.'/live',[$task],$wid,$uid,50)));
            $terms=array_column($data,'keyword');$difficulty=[];
            if($terms){$r=$this->client->call('dataforseo_labs/google/bulk_keyword_difficulty/live',[['keywords'=>$terms,'location_code'=>(int)$market['location_code'],'language_code'=>$market['language_code']]],$wid,$uid,count($terms));foreach(DataForSeoClient::items($r) as $d)$difficulty[mb_strtolower($d['keyword']??'')]=$d['keyword_difficulty']??null;}
            foreach($data as $d)$this->db->query("INSERT INTO seo_keyword_research(website_id,market_id,keyword,volume,difficulty,cpc,intent,source,fetched_at) VALUES(?,?,?,?,?,?,?,'dataforseo',UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE volume=VALUES(volume),difficulty=VALUES(difficulty),cpc=VALUES(cpc),intent=VALUES(intent),fetched_at=VALUES(fetched_at)",[$wid,$mid,$d['keyword'],$d['volume'],$difficulty[mb_strtolower($d['keyword'])]??$d['difficulty'],$d['cpc'],$d['intent']]);
            $this->db->query('REPLACE INTO seo_research_cache VALUES(?,?,?,UTC_TIMESTAMP())',[$wid,$mid,$hash]);
        }
        $rows=$this->db->query('SELECT * FROM seo_keyword_research WHERE website_id=? AND market_id=? AND fetched_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 30 DAY) ORDER BY volume DESC LIMIT 200',[$wid,$mid]);
        return ['available'=>true,'state'=>'measured','from_cache'=>(bool)$cache,'source'=>'dataforseo','keywords'=>$rows,'discovered_keywords'=>array_column($rows,'keyword'),'new_discoveries'=>array_column($rows,'keyword')];
    }
    public function competitors(int $wid,int $uid): void
    {
        $market=(new SeoMarketService($this->db))->get($wid,$uid);if(!$this->client->isConfigured())return;
        $competitors=$this->db->query('SELECT * FROM competitors WHERE website_id=? AND user_id=? AND is_active=1 AND monitoring_paused=0 LIMIT 5',[$wid,$uid]);
        foreach($competitors as $c){$fresh=$this->db->query("SELECT 1 FROM competitor_keywords WHERE competitor_id=? AND market_id=? AND source='dataforseo' AND discovered_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 30 DAY) LIMIT 1",[$c['id'],$market['id']]);if($fresh)continue;
            $r=$this->client->call('dataforseo_labs/google/ranked_keywords/live',[['target'=>DataForSeoRankingSource::host($c['competitor_domain']),'location_code'=>(int)$market['location_code'],'language_code'=>$market['language_code'],'limit'=>50,'order_by'=>['keyword_data.keyword_info.search_volume,desc']]],$wid,$uid,50);
            $data=self::parse(DataForSeoClient::items($r));
            $this->db->transaction(function()use($c,$market,$data){$this->db->query("DELETE FROM competitor_keywords WHERE competitor_id=? AND market_id=? AND source='dataforseo'",[$c['id'],$market['id']]);foreach($data as $d)$this->db->query("INSERT INTO competitor_keywords(competitor_id,market_id,keyword,search_volume,difficulty,position,ranking_url,source,discovered_at) VALUES(?,?,?,?,?,?,?,'dataforseo',UTC_TIMESTAMP())",[$c['id'],$market['id'],$d['keyword'],$d['volume'],$d['difficulty'],$d['position'],$d['url']]);});
        }
    }
    public static function gaps(array $competitors,array $customer): array
    {
        $own=[];foreach($customer as $c)$own[$c['market_id'].'|'.mb_strtolower($c['keyword'])]=$c;
        $out=[];foreach($competitors as $c){$key=$c['market_id'].'|'.mb_strtolower($c['keyword']);$o=$own[$key]??null;
            // Unknown untracked position isn't verified absence. Require a real completed SERP check.
            if(!$o||($o['rank_source']??'')!=='dataforseo'||empty($o['last_checked_at'])||strtotime($o['last_checked_at'].' UTC')<time()-30*86400||empty($c['discovered_at'])||strtotime($c['discovered_at'].' UTC')<time()-30*86400)continue;
            if(($c['source']??'')!=='dataforseo'||$c['position']===null||(int)$c['position']<1||(int)$c['position']>10||$c['search_volume']===null)continue;
            if($o['current_position']===null||(int)$o['current_position']>20){$c['customer_position']=$o['current_position'];$c['evidence_state']='verified_dataforseo';$out[]=$c;}
        }return $out;
    }
    public function gap(int $wid,int $uid): array
    {
        (new SeoMarketService($this->db))->owned($wid,$uid);SeoDataSchema::ensureSchema($this->db);
        $c=$this->db->query("SELECT k.*,c.competitor_domain FROM competitor_keywords k JOIN competitors c ON c.id=k.competitor_id WHERE c.website_id=? AND c.user_id=? AND c.is_active=1 AND k.source='dataforseo'",[$wid,$uid]);
        $own=$this->db->query('SELECT * FROM tracked_keywords WHERE website_id=? AND user_id=?',[$wid,$uid]);return self::gaps($c,$own);
    }
}
